from itertools import count

class User():
    def __init__ (self, first_name, last_name, age, location):
        self.name = first_name.strip().title() + ' ' + last_name.strip().title()
        self.age = age
        self.location = location
        self.login_attempts = 0

    def describe_user (self):
        print('\nThe user\'s name is ' + self.name + ' and they are ' + str(self.age) + ' years old')

    def greet_user(self):
        print('Hello ' + self.name + '!')

    def increment_login_attempts(self):
        self.login_attempts += 1
        print(self.login_attempts)
    
    def reset_login_attempts(self):
        self.login_attempts = 0

class Admin(User):

    def __init__(self, first_name, last_name, age, location):
        super().__init__(first_name, last_name, age, location)
        self.privileges = Privileges()

class Privileges():
    def __init__(self):
        self.privileges = ['can add post', 'can delete post', 'can approve user']

    def show_privileges(self):
        print(self.privileges)    

user1 = Admin('Bob', 'Smith', 26, 'New York')
print(user1.privileges.show_privileges())
