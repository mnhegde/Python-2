import unittest
import main, random


class TestDatabase(unittest.TestCase):
    
    
    def test_editUser(self):
        print('hello')

if __name__ == '__main__':
    unittest.main()