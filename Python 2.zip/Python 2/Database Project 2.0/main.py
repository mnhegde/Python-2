from flask import Flask, render_template, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import update
from datetime import datetime
import json

app = Flask(__name__)

app.config['SECRET_KEY'] = 'hello'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    location = db.Column(db.String(50))
    date_created = db.Column(db.DateTime, default=datetime.now)

class EditUser(db.Model):
    id_num = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    location = db.Column(db.String(50))
    date_created = db.Column(db.DateTime, default=datetime.now)

def getUsers():
    users = db.session.query(User).all()
    print(len(users))
    user_info = {}
    for i in range(len(users)):
        user_info['User %s' %(i+1)] = [users[i].id, users[i].firstname.title() + ' ' + users[i].lastname.title(), users[i].location]
    return json.dumps(user_info)

@app.route('/')
def users():
    return render_template('users.html')

@app.route('/adduser', methods=['GET', 'POST'])
def addPerson():
    if request.method == 'POST':
        data = request.json
        user = User(firstname=data[0], lastname=data[1], location=data[2])
        db.session.add(user)
        db.session.commit()
    else:
        return render_template('adduser.html')

@app.route('/edituser', methods=['GET', 'POST'])
def edituser():
    if request.method == 'POST':
        data = request.json
        print(data)
        user = db.session.query(User).filter(User.id == data).first()
        print(user.firstname)
        editUser = EditUser(id_num=user.id, firstname=user.firstname, lastname=user.lastname, location=user.location)
        db.session.add(editUser)
        db.session.commit()
    else:
        return render_template('edituser.html')

@app.route('/editusermodal', methods=['GET', 'POST'])
def editusermodal():
    if request.method == 'POST':
        data = request.json
        print(data)
        editeduser = db.session.query(EditUser).first()
        updateduser = db.session.query(User).filter(User.id==editeduser.id_num).first()
        updateduser.firstname = data[0]
        updateduser.lastname = data[1]
        db.session.delete(editeduser)
        db.session.commit()

@app.route('/deleteuser', methods=['GET', 'POST'])
def deleteuser():
    if request.method=='POST':
        data = request.json
        user = db.session.query(User).filter(User.id==data).first()
        db.session.delete(user)
        db.session.commit()

@app.route('/addusermodal')
def addUserModal():
    return render_template('addusermodal.html')

@app.route('/editusermodal')
def editUserModal():
    return render_template('editusermodal.html')

@app.route('/api/users', methods = ['GET', 'POST'])
def usersearch():
    if request.method == 'POST':
        search = request.form
        print(search)
        searchresult = {}
        if len(search) == 0 or search == 'all':
            searchresult['results'] = db.session.query(User).all()
        else:
            searchedusers = []
            firstnames = db.session.query(User).filter(User.firstname==search).all()
            lastnames = db.session.query(User).filter(User.lastname==search).all()
            if len(firstnames) > 0:
                for i in range(len(firstnames)):
                    searchedusers.append([firstnames[i].id, firstnames[i].firstname, firstnames[i].lastname])
            if len(lastnames) > 0:
                for i in range(len(lastnames)):
                    searchedusers.append([lastnames[i].id, lastnames[i].firstname, lastnames[i].lastname])
            searchresult['results'] = searchedusers
        print('hello' + searchresult)
        return searchresult
    else:
        users = getUsers()
        if len(users) == 0:
            return 'error'
        else:
            return users

@app.route('/api/edituser')
def editUsers():
    user = db.session.query(EditUser).first()
    if user:
        return json.dumps([user.firstname, user.lastname, user.location])
    else:
        return '<h1>Error! There is no user to edit!</h1>'

@app.route('/users/<search>')
def searchResult(search):
    print(type(search))
    searchResults = []
    if len(search) == 0 or search == 'all':
        results = db.session.query(User).all()
        for i in range(len(results)):
            searchResults.append([results[i].id, results[i].firstname, results[i].lastname, results[i].location])
    
    idResult = db.session.query(User).filter(User.id==search).first()
    if idResult:
        searchResults.append([idResult.id, idResult.firstname, idResult.lastname, idResult.location])

    firstnames = db.session.query(User).filter(User.firstname.like('%{}%'.format(search.lower()))).all()
    lastnames = db.session.query(User).filter(User.lastname.like('%{}%'.format(search.lower()))).all()
    location = db.session.query(User).filter(User.location.like('%{}%'.format(search.lower()))).all()
    for i in range(len(firstnames)):
        searchResults.append([firstnames[i].id, firstnames[i].firstname, firstnames[i].lastname, firstnames[i].location])
    for i in range(len(lastnames)):
        searchResults.append([lastnames[i].id, lastnames[i].firstname, lastnames[i].lastname, lastnames[i].location])
    for i in range(len(location)):
        searchResults.append([location[i].id, location[i].firstname, location[i].lastname, location[i].location])
    print(searchResults)
    return render_template('searchusers.html', users = searchResults)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

