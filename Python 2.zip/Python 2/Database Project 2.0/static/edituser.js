fetch ('/api/edituser')
.then (function (response) {
    return response.json();
})
.then (function (myJson) {
    console.log(myJson)

    firstname = document.getElementById('firstname')
    lastname = document.getElementById('lastname')
    locationinfo = document.getElementById('location')

    firstname.value = myJson[0]
    lastname.value = myJson[1]
})


function EditUser(event) {
    event.preventDefault();

    fullname = [document.getElementById('firstname').value, document.getElementById('lastname').value]
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/editusermodal');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(fullname, null, ' '))

    location = '/editusermodal'
}


form = document.getElementById('form');
form.addEventListener('submit', EditUser)