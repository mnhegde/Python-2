import turtle
import time
from random import randint
from itertools import count

class drawing_Circle:
    count = count(0)

    def __init__ (self, x = 0, y = 0, radius = 50, color = 'red'):
        self.t = turtle.Turtle()
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.count = next(self.count)
    
    def render(self, turtle):
        turtle.penup()
        turtle.color(self.color)
        turtle.fillcolor(self.color)
        turtle.goto(self.x, self.y)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(self.radius)
        turtle.end_fill()
            
colors = []
x_coordinate = []
y_coordinate = []
radius = []
            
number = int(input('How many circles do you want to draw? '))
for x in range(0, number):
    if x == 0:
        circle_color = input('\nWhat color do you want for the first circle? ')
        circle_radius = int(input('What radius do you want for the first circle? '))
        circle_x = int(input('What x-coordinate do you want for the first circle? '))
        circle_y = int(input('What y-coordinate do you want for the first circle? '))
    elif x == number - 1:
        circle_color = input('\nWhat color do you want for the last circle? ')
        circle_radius = int(input('What radius do you want for the last circle? '))
        circle_x = int(input('What x-coordinate do you want for the last circle? '))
        circle_y = int(input('What y-coordinate do you want for the last circle? '))
    else:
        circle_color = input('\nWhat color do you want for the next circle? ')
        circle_radius = int(input('What radius do you want for the next circle? '))
        circle_x = int(input('What x-coordinate do you want for the next circle? '))
        circle_y = int(input('What y-coordinate do you want for the next circle? '))
    colors.append(circle_color)
    x_coordinate.append(circle_x)
    y_coordinate.append(circle_y)
    radius.append(circle_radius)
    circle = drawing_Circle(x = circle_x, y = circle_y, radius = circle_radius, color = circle_color)
    circle.render(turtle)

print('\n You created ' + str(number) + ' circles. You created: ')
for i in range(len(colors)):
    if i == 0:
        print('The 1st circle you created was ' + colors[i] + ' with a radius of ' + str(radius[i]) + '. Its center was at (' + str(x_coordinate[i]) + ', ' + str(y_coordinate[i]) + ').')
    elif i == 1:
        print('The 2nd circle you created was ' + colors[i] + ' with a radius of ' + str(radius[i]) + '. Its center was at (' + str(x_coordinate[i]) + ', ' + str(y_coordinate[i]) + ').')
    elif i == 2:
        print('The 3rd circle you printed was ' + colors[i] + ' with a radius of ' + str(radius[i]) + '. Its center was at (' + str(x_coordinate[i]) + ', ' + str(y_coordinate[i]) + ').')
    else:
        print('The ' + str(i+1) + 'th circle you created was ' + colors[i] + ' with a radius of ' + str(radius[i]) + '. Its center was at (' + str(x_coordinate[i]) + ', ' + str(y_coordinate[i]) + ').')