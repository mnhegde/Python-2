from flask import Flask, render_template, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import update
from datetime import datetime
import json

app = Flask(__name__)

app.config['SECRET_KEY'] = 'hello'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'

db = SQLAlchemy(app)

class User(db.Model):
    #create columns for user
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    location = db.Column(db.String(50))
    date_created = db.Column(db.DateTime, default=datetime.now)

class EditUser(db.Model):
    #columns for saving editeduser
    id_num = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    location = db.Column(db.String(50))
    date_created = db.Column(db.DateTime, default=datetime.now)

def getUsers():
    #get all users from database
    users = db.session.query(User).all()
    user_info = {}
    for i in range(len(users)):
        user_info['User %s' %(i+1)] = [users[i].id, users[i].firstname.title() + ' ' + users[i].lastname.title(), users[i].location]
    return json.dumps(user_info)

@app.route('/')
def users():
    return render_template('users.html')

@app.route('/adduser', methods=['GET', 'POST'])
def addPerson():
    ''' Adds new user with ifnormation entered into form '''
    if request.method == 'POST':
        data = request.json #info from form
        user = User(firstname=data[0], lastname=data[1], location=data[2])
        db.session.add(user)
        db.session.commit()
    else:
        return render_template('adduser.html')

@app.route('/edituser', methods=['GET', 'POST'])
def edituser():
    ''' Gets user selected for editing and saves choice in database to be referenced later '''
    if request.method == 'POST':
        data = request.json
        user = db.session.query(User).filter(User.id == data).first()
        editUser = EditUser(id_num=user.id, firstname=user.firstname, lastname=user.lastname, location=user.location)
        #saves which user was edited
        db.session.add(editUser)
        db.session.commit()
    else:
        return render_template('edituser.html')

@app.route('/editusermodal', methods=['GET', 'POST'])
def editusermodal():
    ''' Gets new info for user and changes attributes of user accordingly '''
    if request.method == 'POST':
        data = request.json
        editeduser = db.session.query(EditUser).first()
        updateduser = db.session.query(User).filter(User.id==editeduser.id_num).first()
        #updateduser has its attributes changed 
        updateduser.firstname = data[0]
        updateduser.lastname = data[1]
        updateduser.location = data[2]
        db.session.delete(editeduser)
        db.session.commit()
    else:
        return render_template('editusermodal.html')

@app.route('/deleteuser', methods=['GET', 'POST'])
def deleteuser():
    ''' Gets user and deletes it '''
    if request.method=='POST':
        data = request.json
        user = db.session.query(User).filter(User.id==data).first() #finds user
        db.session.delete(user)
        db.session.commit()
        return 'good'

@app.route('/addusermodal')
def addUserModal():
    return render_template('addusermodal.html')

@app.route('/api/users')
def usersearch():
    ''' Returns users for user list '''
    users = getUsers()
    if len(users) == 0:
        return 'error'
    else:
        return users

@app.route('/api/edituser')
def editUsers():
    ''' Returns user in EditUser to browser so info can be changed'''
    user = db.session.query(EditUser).first()
    if user:
        return json.dumps([user.firstname, user.lastname, user.location]) #to fill form with info to be edited
    else:
        return '<h1>Error! There is no user to edit!</h1>'

@app.route('/users/<search>')
def searchResult(search):
    '''Gets users based on search from browser. Looks for users based on id, firstname, lastname, and location '''
    searchResults = []
    if len(search) == 0 or search == 'all': #returns all users
        results = db.session.query(User).all()
        for i in range(len(results)):
            searchResults.append([results[i].id, results[i].firstname.title(), results[i].lastname.title(), results[i].location.title()])
    
    idResult = db.session.query(User).filter(User.id==search).first()
    if idResult: #returns users based on id searched
        searchResults.append([idResult.id, idResult.firstname.title(), idResult.lastname.title(), idResult.location.title()])

    firstnames = db.session.query(User).filter(User.firstname.like('%{}%'.format(search.lower()))).all()
    lastnames = db.session.query(User).filter(User.lastname.like('%{}%'.format(search.lower()))).all()
    location = db.session.query(User).filter(User.location.like('%{}%'.format(search.lower()))).all()
    for i in range(len(firstnames)):
        #appends each user that was found by firtsname
        searchResults.append([firstnames[i].id, firstnames[i].firstname.title(), firstnames[i].lastname.title(), firstnames[i].location.title()])
    for i in range(len(lastnames)):
            #appends each user that was found by lastname
        searchResults.append([lastnames[i].id, lastnames[i].firstname.title(), lastnames[i].lastname.title(), lastnames[i].location.title()])
    for i in range(len(location)):
        #appends each user that was found by location
        searchResults.append([location[i].id, location[i].firstname.title(), location[i].lastname.title(), location[i].location.title()])
    
    return render_template('searchusers.html', users = searchResults) #returns searches


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

