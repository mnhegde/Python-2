import unittest
import main, random

db = main.db

class TestDatabase(unittest.TestCase):

    def test_addUser(self):
        firstname = input('Enter firstname: ')
        lastname = input('Enter lastname: ')
        location = input('Enter location: ')
        user = main.User(firstname=firstname, lastname=lastname, location=location)

        db.session.add(user)
        db.session.commit()

        result = db.session.query(main.User).all()

        self.assertEqual(result[-1].firstname, firstname)

    def test_editUser(self):
        users = db.session.query(main.User).all()
        number = random.randint(0, len(users)-1)
        user = users[number]
        userinput_name = input('Enter name: ')
        userinput_location = input('Enter location')
        user = main.EditUser(id_num=users[number].id, firstname=users[number].firstname, lastname=users[number].lastname, location=users[number].location)

        user_id = users[number].id

        db.session.add(user)
        db.session.commit()

        editeduser = db.session.query(main.EditUser).first()
        originaluser = db.session.query(main.User).filter(main.User.id==editeduser.id_num)
        print(originaluser)
        originaluser.firstname = userinput_name.split(' ')[0]
        originaluser.lastname = userinput_name.split(' ')[1]
        originaluser.location = userinput_location
        db.session.delete(editeduser)
        db.session.commit()

        result = db.session.query(main.User).filter(main.User.id==user_id).first()

        self.assertEqual(result.firstname, userinput_name.split(' ')[0])

    def test_deleteUser(self):
        users = db.session.query(main.User).all()
        number = random.randint(0, len(users)-1)
        user = users[number]
        print(user.firstname)

        deletedUser = db.session.query(main.User).filter(main.User.id==user.id).first()

        db.session.delte(deletedUser)
        db.session.commit()

        self.assertEqual(user, deletedUser)

    def test_searchUser(self):
        search = input('Search: ')

        firstnames = db.session.query(main.User).filter(main.User.firstname.like('%{}%'.format(search))).all()
        lastnames = db.session.query(main.User).filter(main.User.lastname.like('%{}%'.format(search))).all()
        locations = db.session.query(main.User).filter(main.User.location.like('%{}%'.format(search))).all()
        user_id = db.session.query(main.User).filter(main.User.id==search).first()

        
        if len(firstnames) > 0:
            self.assertEqual(search, firstnames[i] for i in range(len(firstnames)))
        if len(lastnames) > 0:
            self.assertEqual(search in lastnames[i] for i in range(len(lastnames)))
        if len(locations) > 0:
            self.assertEqual(search in locations[i] for i in range(len(locations)))
        if user_id:
            self.assertEqual(user_id.id==int(search))

        


if __name__ == '__main__':
    unittest.main()



