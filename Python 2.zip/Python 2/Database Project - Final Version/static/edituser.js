fetch ('/api/edituser')
.then (function (response) {
    return response.json();
})
.then (function (myJson) {
    console.log(myJson)
    //inserts info into form to be changed
    firstname = document.getElementById('firstname')
    lastname = document.getElementById('lastname')
    locationinfo = document.getElementById('location')

    firstname.value = myJson[0]
    lastname.value = myJson[1]
    locationinfo.value = myJson[2]
})


function EditUser(event) {
    event.preventDefault();
    //sends edited info to server

    fullname = [document.getElementById('firstname').value, document.getElementById('lastname').value, document.getElementById('location').value]
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/editusermodal');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(fullname, null, ' '))

    location = '/editusermodal'
}


form = document.getElementById('form');
form.addEventListener('submit', EditUser)