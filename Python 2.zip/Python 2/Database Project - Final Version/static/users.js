fetch('/api/users')
.then(function (response) {
    return response.json();
})
.then(function (myJson) {
    if (Object.keys(myJson).length != 0) {
        for(i=0; i<Object.keys(myJson).length; i++) {
            // for each user, adds their info and edit and delete button
            user = document.createElement('h4');
            user.appendChild(document.createTextNode('Id: ' + myJson[`User ${i+1}`][0] + ' ' + myJson[`User ${i+1}`][1]));

            section = document.createElement('div');
            section.appendChild(document.createElement('br'))
            section.setAttribute('class', 'ui container');
            section.appendChild(user);

            locationinfo = document.createElement('h5')
            locationinfo.appendChild(document.createTextNode('Location: ' + toTitleCase(myJson[`User ${i+1}`][2])))
            section.appendChild(locationinfo)

            btn = document.createElement('button');
            btn.innerText = 'Edit'
            btn.style.background = '#26D701';
            btn.setAttribute('class', 'ui button')
            btn.setAttribute('id', myJson[`User ${i+1}`][0]);
            btn.setAttribute('onClick', 'editUser(this)');
            section.appendChild(btn);

            deletebtn = document.createElement('button');
            deletebtn.style.marginLeft = '10px'
            deletebtn.innerText = 'Delete'
            deletebtn.style.background = 'red'
            deletebtn.setAttribute('class', 'ui button')
            deletebtn.setAttribute('id', myJson[`User ${i+1}`][0]);
            deletebtn.setAttribute('onClick', 'showMessage(this)');
            section.appendChild(deletebtn);

            document.body.appendChild(section)
        }
    }
    else {
        section = document.createElement('h1')
        section.appendChild(document.createTextNode('Error! There are no users currently!'))
        document.body.append(section)
    }
    

    })

function toTitleCase(str) {
    // changes string to titlecase
        return str.replace(
            /\w\S*/g,
            function(txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            }
        );
    }




let selectedUser

function showMessage(button) {

    selectedUser = button.getAttribute('id')

    message = document.getElementsByClassName('deleteModal')[0];
    message.style.display = 'block';
}

function deleteUser() {
    // sends info for deleting user
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/deleteuser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(selectedUser, null, ' '));

    cancel()
    location = '/'

}

function cancel() {
    message = document.getElementsByClassName('deleteModal')[0];
    message.style.display = 'none'
}

function editUser(button) {
    // sends info for editing user
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/edituser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(button.getAttribute('id'), null, ' '));

    location = '/edituser'
}

function search() {
    // incorporates search into url
    search = document.getElementById('searchInput').value
    if (search.length == 0){
        location = '/users/all'
    }
    else {
        location = '/users/' + search
    }
    

}


searchButton = document.getElementById('searchButton')
searchButton.addEventListener('click', search)
