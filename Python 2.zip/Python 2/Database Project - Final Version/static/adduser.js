
function add_user(event) {
    //sends into to server
    event.preventDefault()
    data = [document.getElementById('firstname').value, document.getElementById('lastname').value, document.getElementById('city').value]
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/adduser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));

    location = '/addusermodal'
}

form  = document.getElementById('form');
form.addEventListener('submit', add_user)