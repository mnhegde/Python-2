let selectedUser

function showMessage(button) {

    selectedUser = button.getAttribute('id')

    message = document.getElementsByClassName('deleteModal')[0];
    message.style.display = 'block';
}

function deleteUser() {
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/deleteuser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(selectedUser, null, ' '));

    cancel()
    location = '/'

}

function cancel() {
    message = document.getElementsByClassName('deleteModal')[0];
    message.style.display = 'none'
}

function editUser(button) {
    console.log(button.getAttribute('id'))

    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/edituser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(button.getAttribute('id'), null, ' '));

    location = '/edituser'
}


function search() {
    search = document.getElementById('searchInput').value
    if (search.length == 0){
        location = '/users/all'
    }
    else {
        location = '/users/' + search
    }
    
}

searchButton = document.getElementById('searchButton')
searchButton.addEventListener('click', search)