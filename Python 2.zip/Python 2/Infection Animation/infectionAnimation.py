#a simple OO infection model using turtle
#would have included square controlled by user, and a 
#pause, speed up, and slow down button, but the animation of the 
#squares raised issues with detecting clicks and keypresses on the screen

from turtle import *
from tkinter import messagebox
import random
import time

class Square():
    def __init__(self, x, y, vx, vy, color='blue'):
        ''' Creates each individual squares in game. Stores the x and y cor, 
        the x and y velocity, and the color '''
        self.x = x
        self.y = y
        self.vx = vx + .1 #this is velocity for x. .1 in case it's 0
        self.vy = vy + .1 #this is velocity for y. .1 in case it's 0
        self.color = color #determines whether it is infected

    def draw(self):
        ''' Draws the square with corresponding info '''
        penup()
        goto(self.x, self.y)
        pendown()
        color(self.color)
        begin_fill()
        for i in range(4):
            forward(10)
            right(90)
        end_fill()
        hideturtle()

    def checkPos(self):
        ''' After every move, checks pos of square to keep it within boundaries '''
        if -300 > self.x or self.x > 300:
            self.vx = self.vx*-1
        if -300 > self.y or self.y > 300:
            self.vy = self.vy*-1

class SquareManager():
    def __init__(self):
        ''' Keeps track of all squares in game '''
        self.squares = []
        self.infectedSquares = []
        self.setUpTurtle = Turtle() #so that box isn't cleared for animation
        self.startTime = time.time() #for timer
        tracer(0)

        messagebox.showinfo('Welcome!', 'This is a simple infection model, where there is one red square at the start. '+ 
        'When it makes contact with a healthy square (blue), it passes on the infection. The game ends when everything is infected!')

    def drawBox(self, x, y, width):
        ''' Draws box that all squares are contained in '''
        self.setUpTurtle.penup()
        self.setUpTurtle.goto(x, y)
        self.setUpTurtle.pendown()
        for i in range(4):
            self.setUpTurtle.forward(width)
            self.setUpTurtle.right(90)
        self.setUpTurtle.hideturtle()

    def drawSquares(self, numberOfSquares):
        ''' This function creates the squares for the model. It takes the number of squares as an argument
        and creates that many healthy squares. The coordinates, and rate of change are random for each square.
        Then, it creates on infected square with random coordinates and rates, which is added to the infectedSquares list '''
        numberOfSquares = numberOfSquares
        for i in range(numberOfSquares):
            square = Square(random.randint(-299, 299), random.randint(-299, 299), random.randint(-50, 50)*.1, random.randint(-50, 50)*.1)
            square.draw()
            self.squares.append(square)
        
        infectedSquare = Square(random.randint(-299, 299), random.randint(-299, 299), random.randint(-50, 50)*.1, random.randint(-50, 50)*.1, 'red')
        infectedSquare.draw()
        self.infectedSquares.append(infectedSquare)

    def move(self):
        ''' This functions moves the square. To show the animation, the turtle clears everything it has drawn
        and then draws all the healthy squares, after which it adds the rate of change to their coordinates so they move in 
        the next iteration. It does the same for all the infected squares, then updates so that it is smooth. After each iteration, 
        it updates the timer, makes sure to contain the squares in the box, and checks for new collisions '''
        while True:
            clear()
            for square in self.squares:
                square.draw()
                square.x += square.vx
                square.y += square.vy
            for infectedSquare in self.infectedSquares:
                infectedSquare.draw()
                infectedSquare.x += infectedSquare.vx
                infectedSquare.y += infectedSquare.vy
            update()

            self.timer()
            self.checkPos()
            self.checkCollision()

    def timer(self):
        ''' This function runs the timer. self.startTime was a value that was calculated when the game started. Each time this
        is called, the time is taken, and the difference is the amount of time that has passed and is the number displayed '''
        self.endTime = time.time()
        penup()
        color('black')
        goto(-350, 300)
        write('Timer:', align='center', font=('Arial', 10, 'bold'))
        goto(-350, 280)
        write(round(self.endTime-self.startTime, 3), align='center', font=('Arial', 10, 'bold'))

    def checkPos(self):
        ''' This checks the position of the squares to contain them in the box. If they are too far
        along the x-axis, it takes the negative of their x-coordinate rate, and vice versa for the y-axis '''
        for square in self.squares:
            square.checkPos()
        for infectedSquare in self.infectedSquares:
            infectedSquare.checkPos()

    def checkCollision(self):
        ''' This checks for the spread of infection. It goes through all the infected squares and the healthy squares, and sees
        whether the top left corners of the infected square to a healthy square are less than or equal to 10 in terms of x and y. 
        This is the farthest dist possible for squares, as their width is 10. If this is true, that square is infected and moved to the 
        infectedSquares list. If there are no healthy squares, the game ends'''
        if len(self.squares) != 0:
            for infectedSquare in self.infectedSquares:
                for square in self.squares:
                    if abs(infectedSquare.x-square.x) <= 10 and abs(infectedSquare.y - square.y) <= 10: #checks dist
                        square.color = 'red' #indicates it is infected
                        self.infectedSquares.append(square) #moves to new list
                        self.squares.remove(square)
        else:
            messagebox.showinfo('Done!', 'The game is over! Everything is infected! It took ' + str(round(self.endTime-self.startTime, 3)) + ' seconds!')
            bye()

squareManager = SquareManager()
squareManager.drawBox(-310, 310, 620)
squareManager.drawSquares(100)
squareManager.move()

s = Screen()
s.mainloop()