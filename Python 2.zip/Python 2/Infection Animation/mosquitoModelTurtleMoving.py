#this program simulates a mosquito born disease. Specifically for this
#it is random, as it shows the people and mosquitos moving, and the 
#people are bitten if a collision occurs

from turtle import * 
import random, math, time

RATE = 25
LEVELS_OF_OUTDOORNESS = ['low', 'medium', 'high']

class Person():
    def __init__(self, x, y, vx, vy, name):
        '''Attributes for each person. Has different states and position and velocity
        of person '''
        self.x = x
        self.y = y
        self.originalPosition = (x,y)
        self.vx = vx + .1 #in case it's 0
        self.vy = vy + .1 #in case it's 0
        self.outdoorness = random.choice(LEVELS_OF_OUTDOORNESS) #decides outdoor level
        self.tickCount = 0
        self.bittenBy = []
        self.name = name
        self.timesBitten = 0
        self.bitten = False
        self.infected = False
        self.vaccinated = False
        self.dead = False
        self.immune = False
        self.outside = False

    def draw(self):
        '''Draws person '''
        color('green')
        if self.bitten:
            color('orange')
        if self.infected:
            color('red')
        if self.vaccinated:
            color('blue')
        if self.dead:
            color('black')
        goto(self.x, self.y)
        shape('square')
        stamp()

    def tick(self):
        '''Runs for each person for each tick. Updates position and checks if they have recovered
        from bite or disease '''
        self.x += self.vx
        self.y += self.vy
        self.checkPos()
        self.timeBitten()
        self.draw()


    def timeBitten(self):
        '''Ater a certain amount of time, a person will recover from their state depending on the tickcount
         It also determines whether the person dies '''
        if self.infected:
            if self.tickCount == 500:
                self.tickCount = 0
                self.infected = False
            elif self.tickCount%100==0:
                if random.randint(0,100) < 10:
                    self.dead = True  
                    self.vx = 0
                    self.vy = 0 
                else:
                    self.tickCount+=1
            else:
                self.tickCount+=1

        elif self.bitten:
            if self.tickCount == 1000:
                self.tickCount = 0
                self.bitten = False
                self.bittenBy = []
            else:
                self.tickCount +=1

    def checkPos(self):
        '''Contains people within designated area '''
        if not self.outside:
            if -130>self.x or 130 < self.x:
                self.vx = self.vx*-1
            if -130>self.y or 130 < self.y:
                self.vy = self.vy*-1
        else:
            Mosquito.checkPos(self)

    def checkInfection(self):
        ''' Determines whether person gets infected based on RATE'''
        if random.randint(0,100) <= RATE:
            self.infected = True
            if self.outside:
                self.outside = False
                self.x = self.originalPosition[0]
                self.y = self.originalPosition[1]


class Mosquito():
    def __init__(self, x, y, vx, vy, name):
        '''Sets position and velocity '''
        self.x = x
        self.y = y
        self.vx = vx + .1
        self.vy = vy + .1
        self.name = name

    def draw(self):
        '''Draws mosquito'''
        color('red')
        shape('classic')
        goto(self.x, self.y)
        stamp()

    def checkPos(self):
        '''Keeps mosquitos within designated space '''
        if -(window_width()//2) + 10 > self.x or (window_width()//2) - 10 < self.x:
            self.vx = self.vx*-1
        if -(window_height()//2) + 10 > self.y or (window_height()//2) - 10 < self.y:
            self.vy = self.vy*-1

        if -160<self.x<160 and -160<self.y<160:
            self.vx = self.vx*-1
            self.vy = self.vy*-1

    def tick(self):
        '''Runs for each mosquito for each tick. Updates position and runs checkPos '''
        self.x += self.vx
        self.y += self.vy
        self.checkPos()
        self.draw()


class Population():
    def __init__(self, peopleSize, mosquitoSize, nvaccinated):
        '''Sets attributes for the simulation '''
        self.numberofPeople = peopleSize
        self.numberOfMosquitos = mosquitoSize
        self.nvaccinated = nvaccinated
        self.setUpTurtle = Turtle()
        self.timer = Turtle() #writes season
        self.timer.hideturtle()
        self.timer._tracer(0)
        self.timer.goto(-325, 300)
        self.population = []
        self.mosquitos = []
        self.runCount = 0
        self.t0 = time.time()
        self.t1 = time.time()
        self.seasons = ['spring', 'summer', 'fall', 'winter']
        self.currentSeason = 0
        self.peopleRows = math.ceil(math.sqrt(peopleSize))
        self.mosquitoRows = math.ceil(math.sqrt(mosquitoSize))
        penup()
        hideturtle()
        tracer(0)

    def createPeople(self):
        '''Creates people depending on number given. Gives them random
        coordinates and velocity, and adds them to population list '''
        self.drawBox(-150, 150, 300, 300)
        self.setUpTurtle.penup()
        self.setUpTurtle.goto(-0, 150)
        self.setUpTurtle.write('People:', align='center', font=('Arial', 10, 'bold'))
        shapesize(.6)
        for i in range(self.numberofPeople):
            x = random.randint(-125, 125)
            y = random.randint(-125, 125)
            vx = random.randint(-12, 12)*.1
            vy = random.randint(-12, 12)*.1
            self.population.append(Person(x, y, vx, vy, str(i)))
        for i in range(self.numberofPeople):
            self.population[i].draw()

        for i in range(self.nvaccinated):
            #determines those that are vaccinated
            while True:
                person = random.randint(0, len(self.population) - 1)
                if not self.population[person].vaccinated:
                    break
            self.population[person].vaccinated = True
    
    def createMosquitos(self):
        '''Creates mosquitos '''
        shapesize(.8)
        self.setUpTurtle.penup()
        for i in range(self.numberOfMosquitos):
            if i < self.numberOfMosquitos//4:
                x = random.randint(-300, -160)
                y = random.randint(-300, 300)
            elif i < self.numberOfMosquitos//2:
                y = random.randint(-300, -160)
                x = random.randint(-300, 300)
            elif i < int(self.numberOfMosquitos*.75):
                y = random.randint(160, 300)
                x = random.randint(-300, 300)
            else:
                x = random.randint(160, 300)
                y = random.randint(-300, 300)
            vx = random.randint(-50, 50)*.1
            vy = random.randint(-50, 50)*.1
            self.mosquitos.append(Mosquito(x, y, vx, vy, str(i)))
        for i in range(self.numberOfMosquitos):
            self.mosquitos[i].draw()

        self.tick() 

    def drawBox(self, x, y, length, width):
        '''Function that draws a box with x,y starting pos, nd length and width '''
        self.setUpTurtle.penup()
        self.setUpTurtle.goto(x, y)
        self.setUpTurtle.pendown()
        for i in range(2):
            self.setUpTurtle.forward(length)
            self.setUpTurtle.right(90)
            self.setUpTurtle.forward(width)
            self.setUpTurtle.right(90)
        self.setUpTurtle.hideturtle()

    def tick(self):
        '''Runs for each tick. Keeps calling itself. it runs the tick function
        for each person and mosquito, and runs other functions to keep track of simulation '''
        clear()
        for mosquito in self.mosquitos:
            mosquito.tick()
        for person in self.population:
            person.tick()
        update()

        self.changeSeason()
        self.bitten()
        self.outsidePerson()
        self.bittenPeople()
        self.mosquitoChange()
        ontimer(self.tick, 10)

    def bittenPeople(self):
        '''Using outdoorness level, moves peope back "inside" after certain number of bites
        Higher the level, more bites can be withstood '''
        for person in self.population:
            if person.outside:
                if person.outdoorness == 'low' and person.timesBitten > 3:
                    person.x = person.originalPosition[0]
                    person.y = person.originalPosition[1]
                    person.outside = False
                elif person.outdoorness == 'medium' and person.timesBitten > 5:
                    person.x = person.originalPosition[0]
                    person.y = person.originalPosition[1]
                    person.outside = False
                elif person.outdoorness == 'high' and person.timesBitten > 7:
                    person.x = person.originalPosition[0]
                    person.y = person.originalPosition[1]
                    person.outside = False

    def outsidePerson(self):
        '''Function that moves a person "outside". Moves one person every second '''
        if time.time() - self.t1 > 1:
            self.t1 = time.time()
            while True:
                person = random.randint(0,len(self.population)-1)
                if not self.population[person].outside and not self.population[person].dead:
                    break
            self.population[person].outside = True
            self.population[person].originalPosition = (self.population[person].x, self.population[person].y)
            if random.randint(1,10)%2 == 0:
                self.population[person].x = random.randint(160, 300)
            else:
                self.population[person].x = random.randint(-300, -160)
            self.population[person].y = random.randint(-300, 300)
            self.population[person].timeOutside = time.time()

    def bitten(self):
        '''THis function checks whether there have been any collisions between the mosquitos and people '''
        for mosquito in self.mosquitos:
            for person in self.population:
                if abs(mosquito.x-person.x) <= 15 and abs(mosquito.y-person.y) <= 15 and not person.vaccinated and mosquito not in person.bittenBy:
                    person.bittenBy.append(mosquito)
                    person.bitten = True
                    ontimer(person.checkInfection, 5000)
                    person.timesBitten += 1
                

    def mosquitoChange(self):
        '''This keeps track of the season, and affects the mosquitos accordingly '''
        if self.runCount == 0:
            if self.seasons[self.currentSeason] == 'winter':
                #decreases # of mosquitos
                for mosquito in self.mosquitos:
                    mosquito.vx = mosquito.vx*.5
                    mosquito.vy = mosquito.vy*.5
                for i in range(len(self.mosquitos)//2):
                    self.mosquitos.pop()
                self.runCount += 1
            if self.seasons[self.currentSeason] == 'summer':
                #increases # of mosquitos
                for i in range(len(self.mosquitos)//5):
                    x = random.randint(160, 300)
                    y = random.randint(-300, 300)
                    vx = random.randint(-50, 50)*.1
                    vy = random.randint(-50, 50)*.1
                    self.mosquitos.append(Mosquito(x, y, vx, vy, 1))
                self.runCount+=1

    def changeSeason(self):
        '''This function manages the seasons. It changes the season every 15 seconds '''
        if time.time()-self.t0 > 15:
            self.t0 = time.time()
            self.runCount = 0
            if self.currentSeason == 3:
                self.currentSeason = 0
            else:
                self.currentSeason += 1
        self.timer.clear()
        self.timer.goto(self.timer.xcor()-30, self.timer.ycor())
        self.timer.write('Season:', align='center', font=('Arial', 10, 'bold'))
        self.timer.goto(self.timer.xcor()+30, self.timer.ycor())
        self.timer.write(self.seasons[self.currentSeason].title(), font=('Arial', 10, 'bold'))

population = Population(25, 64, 2)
population.createPeople()
population.createMosquitos()

s = Screen()
s.mainloop()