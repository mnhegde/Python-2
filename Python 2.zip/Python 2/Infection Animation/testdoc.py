import turtle, math, random

INFECTION_RATE = 50 # percentage chance of infection...
SCREEN_SIZE = 700
ORIGIN = [-200,200]

class Person:

  def __init__ (self, id):
    self.id = id
    self.exposed = False
    self.infected = False
    self.contagious = False   
    self.neighbors = []    

  def tick (self):
    if self.infected:
      self.contagious = True
    self.exposeToNeighbors()

  def addNeighbor (self, neighbor):
    self.neighbors.append(neighbor)
  
  def exposeToNeighbors (self):
    if (not self.exposed):
      for neighbor in self.neighbors:
        if neighbor.contagious:
          self.exposeToInfection(neighbor)
  
  def exposeToInfection (self, neighbor):
    self.exposed = True 
    if random.randint(0,100) < INFECTION_RATE:
      self.infected = True
  
  def infectDirectly (self,*args):
    self.infected = True
    self.contagious = True

  @property
  def status (self):
    if self.infected:
      return 'INF'
    elif self.exposed:
      return 'EXP'
    else:
      return ''

  def __repr__ (self):
      return '%s%s'%(
        self.id,
        self.status
      )

# We have an array of people in a grid...
#
# e.g.
# 00 01 02 03
# 04 05 06 07
# 08 09 10 11
# 12 13 14 15
#
# So neighbors are going to be...
# of e.g. 5...
# 4: n - 1
# 6: n + 1
# 1: n - sideSize
# 9: n+ sideSize
# 8: n + (sideSize - 1)
# 10: n + (sideSize + 1)
# 0 : n - sideSize - 1
# 2 : n - sideSize + 1

class Population:

  def __init__ (self, size):
    self.tickCount = 0
    self.exposedLastRound = 0
    self.data = []
    self.complete = False
    sideSize = int(math.ceil(math.sqrt(size))) # square root...
    self.population = []
    # Generate population
    for i in range(size):
      self.population.append(Person(i))
    # Create neighbors...
    for i in range(size):
      # neighbor reach == 1
      rowPos = i % sideSize
      #print(i,rowPos)
      potentialNeighbors = [i+sideSize,i-sideSize] # row up, row down
      if (sideSize - 1) > rowPos:
        potentialNeighbors.extend([i+1,i+sideSize+1,i-sideSize+1]) # to the right
      if rowPos > 0:
        potentialNeighbors.extend([i-1,i+sideSize-1,i-sideSize-1]) # to the left
      person = self.population[i]
      for n in potentialNeighbors:
        if n > 0 and n < len(self.population):
          person.neighbors.append(self.population[n])

  def tick (self,*args):
    nsick = 0
    nexposed = 0
    roundData = []
    for p in self.population:
      p.tick()
      if p.exposed: nexposed += 1
      if p.infected: nsick += 1
      roundData.append(p)
    self.data.append(roundData)
    self.tickCount += 1    
    if self.exposedLastRound==nexposed:
      self.complete = True
    else:
      self.complete = False
      self.exposedLastRound = nexposed

def runSimulation ():
  p = Population(144)
  sicko = random.choice(p.population)
  sicko.infectDirectly()
  while not p.complete:
    p.tick()  
  
  patientZero = [p for p in p.data[0] if p.infected][0]
  exposed = [p for p in p.data[-1] if p.exposed]
  infected = [p for p in p.data[-1] if p.infected]
  #print('Patient Zero was: %s; Infected %s of %s exposed'%(
  #patientZero.id,len(infected),len(exposed)
  #))
  neighbors = [len(p.neighbors) for p in p.population]
  #print('Neighbor max/min/avg: ','')
  #print(max(neighbors),'')
  #print(min(neighbors),'')
  #print(sum(neighbors)/len(neighbors))  
  return [patientZero,len(infected),len(exposed),p.data]

summaryData = []
nsims = 1000
for i in range(nsims):
  summaryData.append(runSimulation())
  print('.',end='',flush=True)
print()
print('Average number of neighbors',
      
)
print('Max infected:',max([d[1] for d in summaryData]))
print('Avg infected:',sum([d[1] for d in summaryData])/nsims)
print('Min infected:',min([d[1] for d in summaryData]))
print('Max exposed:',max([d[2] for d in summaryData]))
print('Min exposed:',min([d[2] for d in summaryData]))
print('Avg exposed:',sum([d[2] for d in summaryData])/nsims)

