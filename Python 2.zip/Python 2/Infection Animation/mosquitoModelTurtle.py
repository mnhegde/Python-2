#a turtle model that simulates a mosquito born disease
#there are multiple states for each person, and there
#variables for the chance of getting bitten, sick, and dying

from turtle import *
import random, time, math


class Person():
    def __init__(self, x, y, name, biteRate, infectionRate, deathRate):
        '''Attributes for each person '''
        self.x = x
        self.y = y
        self.name = name
        self.BITERATE = biteRate
        self.INFECTIONRATE = infectionRate
        self.DEATHRATE = deathRate
        self.nBites = 0
        self.tickCount = 0

        self.bitten = False
        self.infected = False
        self.vaccinated = False
        self.dead = False

    def draw(self):
        '''Draws person '''
        color('green')
        if self.bitten:
            color('orange')
        if self.infected:
            color('red')
        if self.vaccinated:
            color('blue')
        if self.dead:
            color('black')

        goto(self.x, self.y)
        stamp()

    def tick(self):
        '''Runs for each person for each tick. Sees whether they are bitten, updates their state '''
        self.tickCount += 1
        self.exposeToMosquitos()
        self.chanceOfDeath()
        self.timePassed()
        self.draw()

    def timePassed(self):
        '''Checks time that has passed since person was bitten or got sick based on tickCount
        After certain amount, the person recovers '''
        if self.infected:
            if self.tickCount - self.currentTickCount == 2:
                self.infected = False

        elif self.bitten:
            if self.tickCount - self.currentTickCount == 3:
                self.bitten = False


    def exposeToMosquitos(self):
        '''Checks whether person is bitten by using BITERATE '''
        if random.randint(0,100) <= self.BITERATE:
            self.currentTickCount = self.tickCount
            self.bitten = True
            self.nBites += 1

            self.exposeToInfection()

    def exposeToInfection(self):
        ''' Checks whether person is infected/gets sick by using INFECTIONRATE '''
        if not self.infected:
            if random.randint(0,100) <= self.INFECTIONRATE:
                self.infected = True
                

    def chanceOfDeath(self):
        '''After being infected for at least 1 tick, sees whether person has chance of dying '''
        if self.infected and self.tickCount > 1:
            if random.randint(0,100) <= self.DEATHRATE:
                self.dead = True
        

class Mosquito():
    def __init__(self, x, y, name):
        '''Sets attributes for Mosquito. Essentially only their position '''
        self.x = x
        self.y = y
        self.name = name

    def draw(self):
        '''Draws mosquito on screen '''
        color('red')
        goto(self.x, self.y)
        stamp()

class Population():
    def __init__(self, peopleSize, mosquitoSize, nvaccinated, biteRate, infectionRate, deathRate):
        '''Sets all the different attributes needed to run the simulation. When creating an instance
        of the class, can set the people and mosquito size, as well as the rates for the bites, getting sick,
        and death '''
        self.peopleRows = math.ceil(math.sqrt(peopleSize))
        self.mosquitoRows = math.ceil(math.sqrt(mosquitoSize))
        self.nvaccinated = nvaccinated
        self.people = []
        self.mosquitos = []
        self.timer = Turtle() #turtle that writes season
        self.timer.hideturtle()
        self.timer.penup()
        self.timer.goto(-300, 300)
        self.seasons = ['spring', 'summer', 'fall', 'winter']
        self.currentSeason = 0
        self.seasonChanged = False
        self.t0 = time.time()
        self.counter = Turtle() #turtle that writes data
        self.counter.hideturtle()
        self.counter.penup()
        self.tickCount = 0
        self.BITERATE = biteRate
        self.INFECTIONRATE = infectionRate
        self.DEATHRATE = deathRate
        tracer(0)
        penup()
        
        for i in range(peopleSize):
            #creates all the people
            x = -300 + (i%self.peopleRows)*30
            y = 200 - (i//self.peopleRows)*30
            self.people.append(Person(x, y, str(i), self.BITERATE, self.INFECTIONRATE, self.DEATHRATE))

        for i in range(mosquitoSize):
            #creates all the mosquitos
            x = 0 + (i%self.mosquitoRows)*30
            y = 200 - (i//self.mosquitoRows)*30
            self.mosquitos.append(Mosquito(x, y, str(i)))

        for i in range(self.nvaccinated):
            #chooses random person to be vaccinated
            while True:
                person = random.randint(0,len(self.people)-1)
                if not self.people[person].vaccinated: #makes sure same person isn't picked
                    break
            self.people[person].vaccinated = True

        
        x = 0+((self.mosquitoRows-1)*30)//2
        self.counter.goto(x, 225)
        self.counter.write('Mosquitos')
        self.counter.goto(400,300)

        for person in self.people:
            person.draw()
        for mosquito in self.mosquitos:
            mosquito.draw()

    def tick(self):
        '''Runs for every tick. Calls itself until simulation is over '''
        clear()
        ndead = 0
        nbitten = 0
        nsick = 0

        for person in self.people:
            person.tick() #runs tick function for each person
        for mosquito in self.mosquitos:
            mosquito.draw()
        update()
        self.changeSeason()
        self.tickCount+=1

        x,y = self.counter.pos()
        if abs(-(window_height()/2) - y) <= 100:
            self.counter.goto(x+150,250) #if data reaches bottom of screen, moves to right
        else:
            self.counter.goto(x, y-50)

        for person in self.people:
            if person.dead:
                ndead += 1
            if person.bitten:
                nbitten+=1
            if person.infected:
                nsick+=1

        self.counter.write('Round %s: \n%s bitten, %s infected, %s dead'%(
            self.tickCount,
            nbitten,
            nsick,
            ndead      
        )) #write data for the tick
        
        if ndead == len(self.people): #ends if everyone is dead
            self.counter.goto(x,y-100)
            self.counter.write('After %s rounds, everyone has died!'% (self.tickCount))
        else:
            ontimer(self.tick, 2000)

    def changeSeason(self):
        '''keeps track of time, and changes season after designated time has passed
        Also affects mosqutios depending on the season '''
        if time.time()-self.t0 > 10: #changes season after 10 seconds
            self.t0 = time.time()
            self.runCount = 0
            if self.currentSeason == 3:
                self.currentSeason = 0
            else:
                self.currentSeason += 1
            self.seasonChanged = False

        self.timer.clear()
        self.timer.goto(self.timer.xcor()-30, self.timer.ycor())
        self.timer.write('Season:', align='center', font=('Arial', 10, 'bold'))
        self.timer.goto(self.timer.xcor()+30, self.timer.ycor())
        self.timer.write(self.seasons[self.currentSeason].title(), font=('Arial', 10, 'bold'))

        if self.seasons[self.currentSeason] == 'summer' and not self.seasonChanged:
            #increase mosquitos and bite rate for summer
            self.BITERATE = self.BITERATE*2
            for i in range(len(self.mosquitos)//2):
                x = self.mosquitoRows*30 + (i%(self.mosquitoRows//2))*30
                y = 200 - (i//(self.mosquitoRows//2))*30
                self.mosquitos.append(Mosquito(x, y, str(i)))
            self.seasonChanged = True #makes this change only run once

        if self.seasons[self.currentSeason] == 'winter' and not self.seasonChanged:
            #decreases biterate and mosquitos for winter
            self.BITERATE = self.BITERATE*.5
            for i in range(len(self.mosquitos)//2):
                self.mosquitos.pop()
            self.seasonChanged = True #makes this change only run once


p = Population(64, 64, 5, 20, 10, 5)
screensize(10000)
ontimer(p.tick, 1000)

mainloop()
