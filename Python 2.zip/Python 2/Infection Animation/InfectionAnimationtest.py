import turtle, math, random

INFECTION_RATE = 50 # percentage chance of infection...
SCREEN_SIZE = 500
turtle.screensize(1000, 750)
ORIGIN = [-200,200]

class Person:

  def __init__ (self, x, y, name):
    self.x,self.y = x,y
    self.name = name
    self.exposed = False
    self.infected = False
    self.contagious = False   
    self.neighbors = []    

  def display (self):    
    turtle.color('black')
    if self.exposed:
      turtle.color('green')
    if self.infected:
      turtle.color('purple')
    if self.contagious:
      turtle.color('red')
    turtle.goto(self.x,self.y)
    turtle.stamp()
    turtle.write(self.name)

  def tick (self):
    if self.infected:
      self.contagious = True
    self.exposeToNeighbors()
    self.display()

  def addNeighbor (self, neighbor):
    self.neighbors.append(neighbor)
  
  def exposeToNeighbors (self):
    if (not self.exposed):
      for neighbor in self.neighbors:
        if neighbor.contagious:
          self.exposeToInfection(neighbor)
  
  def exposeToInfection (self, neighbor):
    self.exposed = True 
    if random.randint(0,100) < INFECTION_RATE:
      self.infected = True
  
  def infectDirectly (self,*args):
    print('Infect!')
    self.infected = True


# We have an array of people in a grid...
#
# e.g.
# 00 01 02 03
# 04 05 06 07
# 08 09 10 11
# 12 13 14 15
#
# So neighbors are going to be...
# of e.g. 5...
# 4: n - 1
# 6: n + 1
# 1: n - sideSize
# 9: n+ sideSize
# 8: n + (sideSize - 1)
# 10: n + (sideSize + 1)
# 0 : n - sideSize - 1
# 2 : n - sideSize + 1

class Population:

  def __init__ (self, size):
    self.exposedLastRound = 0
    self.counter = turtle.Turtle()
    self.counter.up()
    self.counter.onclick(self.tick)
    self.tickCount = 0
    self.counter.goto(ORIGIN[0]+SCREEN_SIZE+10,ORIGIN[1] + 100)
    sideSize = int(math.ceil(math.sqrt(size))) # square root...
    spacing = SCREEN_SIZE / sideSize
    self.population = []
    self.infected = []
    for i in range(size):
      x = ORIGIN[0] + ((i % sideSize) * spacing)
      y = ORIGIN[1] - ((i // sideSize) * spacing)
      self.population.append(Person(x,y,str(i)))
    for i in range(size):
      # neighbor reach == 1
      rowPos = i % sideSize
      #print(i,rowPos)
      potentialNeighbors = [i+sideSize,i-sideSize] # row up, row down
      if (sideSize - 1) > rowPos:
        potentialNeighbors.extend([i+1,i+sideSize+1,i-sideSize+1]) # to the right
      if rowPos > 0:
        potentialNeighbors.extend([i-1,i+sideSize-1,i-sideSize-1]) # to the left
      person = self.population[i]
      for n in potentialNeighbors:
        if n > 0 and n < len(self.population):
          person.neighbors.append(self.population[n])
      #print person.name,'rowpos',rowPos,'has neighbors',
      #print [n.name for n in person.neighbors]

  def tick (self,*args):
    nexposed = 0
    nsick = 0
    for p in self.population:
      p.tick()
    #self.counter.clear()
    x,y = self.counter.pos()
    self.counter.goto(x,y-50)
    self.tickCount += 1
    for person in self.population:
        if person.exposed:
            nexposed += 1
        if person.infected:
            nsick += 1
    self.counter.write('Round %s: \n%s exposed, %s infected'%(
      self.tickCount,
      nexposed,
      nsick      
      ))

    turtle.update()
    if self.exposedLastRound == nexposed:
        self.counter.goto(x,y-100)
        self.counter.write('No new exposures: simulation done')
        turtle.update()
    else:
        self.exposedLastRound = nexposed
        turtle.Screen().ontimer(self.tick,500)


turtle.tracer(0)
turtle.up()
turtle.shape('turtle')
p = Population(64)
sicko = random.choice(p.population)
sicko.infectDirectly()

p.tick()

turtle.mainloop()



