#computational model that simulates a mosquito born disease
#has variables for number of people and mosquitos, those who are vaccinated
# and the rate of getting bitten, sick, or dying

import random, time, math, prettytable
from progress.bar import IncrementalBar

class Person():
    def __init__(self, name, biteRate, infectionRate, deathRate):
        '''Attributes for each person '''
        self.name = name
        self.BITERATE = biteRate
        self.INFECTIONRATE = infectionRate
        self.DEATHRATE = deathRate
        self.nBites = 0
        self.tickCount = 0
        self.symbol = '-'
        self.bitten = False
        self.infected = False
        self.vaccinated = False
        self.dead = False

    def tick(self):
        '''Runs for each person for each tick '''
        self.tickCount += 1
        self.exposeToMosquitos()
        self.chanceofDeath()
        self.timePassed()

    def exposeToMosquitos(self):
        ''' Function that sees whether person is bitten '''
        if random.randint(0,100) <= self.BITERATE:
            self.currentTickCount = self.tickCount
            self.bitten = True
            self.nBites += 1

            self.exposeToInfection()

    def timePassed(self):
        ''' Function tracking time after bite or infection. After the time, the person will recover'''
        if self.infected:
            if self.tickCount - self.currentTickCount == 3:
                self.infected = False

        elif self.bitten:
            if self.tickCount - self.currentTickCount == 3:
                self.bitten = False

    def exposeToInfection(self):
        ''' Runs to see whether person is infected '''
        if not self.infected:
            if random.randint(0,100) <= self.INFECTIONRATE:
                self.infected = True

    def chanceofDeath(self):
        ''' Determines whether person dies'''
        if self.infected and self.tickCount > 1:
            if random.randint(0,100) <= self.DEATHRATE:
                self.dead = True

class Mosquito():
    #this isn't even needed. Don't need class for mosquitos, just need to know number
    #of mosquitos at current time
    def __init__(self, name):
        self.name = name

class Population():
    def __init__(self, peopleSize, mosquitoSize, nvaccinated, biteRate, infectionRate, deathRate):
        '''Attributes for the whole simulation. Assigns all the variables that affect the simulation
        ALso creates attributes to keep track of time an population'''
        self.peopleSize = peopleSize
        self.mosquitoSize = mosquitoSize
        self.nvaccinated = nvaccinated
        self.BITERATE = biteRate
        self.INFECTIONRATE = infectionRate
        self.DEATHRATE = deathRate
        self.complete = False

        self.tickCount = 0
        self.population = []
        self.mosquitos = []
        self.seasons = ['spring', 'summer', 'fall', 'winter']
        self.currentSeason = 0
        self.year = 1
        self.t0 = time.time()

        for i in range(peopleSize):
            #creates people
            self.population.append(Person(str(i), biteRate, infectionRate, deathRate))
        for i in range(mosquitoSize):
            #creates mosquitos
            self.mosquitos.append(Mosquito(str(i)))

    def tick(self):
        ''' This function runs for every tick. Calls the tick function for each person, and calling ticks
        when everyone is dead '''
        nsick = 0
        nbitten = 0
        ndead = 0
        for person in self.population:
            person.tick()
            if person.bitten:
                nbitten += 1
            if person.infected:
                nsick+=1
            if person.dead:
                ndead+=1
        self.tickCount+=1
        self.changeSeason()

        if ndead == len(self.population):
            self.complete = True

    def changeSeason(self):
        ''' This keeps track and changes season every certain # of ticks.
        Different seasons will affect the mosquitos and bite rate '''
        if self.tickCount%10 == 0 and self.tickCount != 0:
            if self.currentSeason == 3:
                self.currentSeason = 0
            else:
                self.currentSeason+=1
            self.seasonChanged = False
            self.year+=.25

        if self.seasons[self.currentSeason] == 'summer' and not self.seasonChanged:
            #adds more mosquitos and increases bite rate
            for i in range(self.mosquitoSize//2):
                self.mosquitos.append(Mosquito(str(i)))
            self.seasonChanged = True
            self.BITERATE = self.BITERATE*1.5
        
        if self.seasons[self.currentSeason] == 'winter' and not self.seasonChanged:
            #lessens mosquitos and decreases bite rate
            for i in range(self.mosquitoSize//2):
                self.mosquitos.pop()
            self.seasonChanged = True
            self.BITERATE = self.BITERATE*.5
        

def runSimulation():
    '''Function that runs simulation. Runs ticks for Population class, and collects and returns data once ticks stop'''
    p = Population(64, 64, random.randint(0,32), random.randint(1,500)*.1, random.randint(1,500)*.1, random.randint(1,500)*.1)
    while not p.complete:
        p.tick()
    bitten = 0
    sick = 0
    alive = 0
    for person in p.population:
        if person.bitten:
            bitten+=1
        if person.infected:
            sick+=1
        if not person.dead:
            alive +=1
    return [p.tickCount, p.year, bitten, sick, p.nvaccinated, p.BITERATE, p.INFECTIONRATE, p.DEATHRATE]

def printData(categories, data):
    '''Prints data into table format. Iterates through list of categories, and adds row with corresponding data '''
    print('\nTable - Data from %s Simulations:'%(nsims))
    t = prettytable.PrettyTable(['Category', 'Avg', 'Max', 'Min']) #displays data in table
    for i in range(len(categories)):
    #iterates through categories list, and adds new row each time. Row contains data corresponding to category. Gets data by indexing
        t.add_row([categories[i], round(sum(d[i] for d in data)/nsims, 3), round(max(d[i] for d in data), 3), round(min(d[i] for d in data), 3) ])
    print(t)

summaryData = []
categories = ['# of Rounds', '# of Years', 'Bitten', 'Infected', 'Vaccinated', 'Bite Rate', 'Infection Rate', 'Death Rate']
nsims = 100
pbar = IncrementalBar('Running Simulations...', max=nsims, suffix = '%(percent).1f%% | %(eta)dsecs') #progress bar
for i in range(nsims):
    #runs a simulation and updates progress bar
    summaryData.append(runSimulation())
    pbar.next() #updates progress bar
pbar.finish() #finishes bar

printData(categories, summaryData)

