import turtle
from random import randint, choice
from tkinter import messagebox

class Circle():
    ''' Each circle drawn is an instance of Circle() '''
    def __init__ (self, t, x, y, color, radius):
        ''' defines all variables for each circle object '''
        self.t = t
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color

    def draw(self):
        ''' draws circle on canvas '''
        self.t.speed(10)
        self.t.penup()
        self.t.color(self.color)
        self.t.fillcolor(self.color)
        self.t.goto(self.x, self.y)
        self.t.pendown()
        self.t.begin_fill()
        self.t.circle(self.radius)
        self.t.end_fill()

    def ifClicked(self, x, y):
        ''' sees whether click was inside a circle. If true, returns circle's info '''
        if (self.x - self.radius) <= x <= (self.x + self.radius) and self.y <= y <= (self.y + (2*self.radius)):
            messagebox.showinfo('This is the circle you clicked on: ', 'My coordinates are (' + str(self.x) + ', ' 
            + str(self.y) + '). My color is ' + self.color + ' and my radius is ' + str(self.radius) + '.')


class CircleManager():
    def __init__ (self):
        ''' Defines lists and attributes that apply to all circles '''
        self.t = turtle.Turtle()
        self.undoActions = []
        self.colors = ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'black', 'brown', 'yellow', 'gold', 
                        'orange', 'red', 'maroon', 'violet', 'magenta', 'purple', 'navy', 'blue', 'skyblue', 
                        'cyan', 'turquoise', 'lightgreen', 'green', 'darkgreen', 'chocolate', 'brown', 'black', 
                        'gray', 'gainsboro', 'midnight blue', 'cornflower blue', 'royal blue', 'dim gray']
        self.drawings = []
        self.popupmsg('Welcome!', 'With this program, a circle with a random color and radius will be drawn ' + 
        'wherever you left-click. You can undo ("z" key) and redo ("y" key) actions while drawing, and you ' +  
        'can reset the drawing board with "Escape". Right-click on a circle to get its info too.')

    def addCircle(self, x, y):
        ''' creates new instance of Circle() each time it is called
            so that each circle drawn is an object. Calls functions from Circle() '''
        color = choice(self.colors) #random color
        radius = randint(50, 150)   # random radius
        myCircle = Circle(self.t, x, y, color, radius)
        myCircle.draw()
        self.drawings.append(myCircle) #adds circle object to list
        self.undoActions = []
    
    def reset(self):
        ''' clears canvas and circles from list drawings '''
        self.t.reset()
        self.drawings = []

    def undo(self):
        ''' undo the last thing drawn by turtle '''
        if not self.drawings:
            #error if there is nothing to undo
           self.popupmsg('Error!', 'There is nothing to undo!')
        self.undoActions.append(self.drawings[-1])
        self.drawings.pop()
        for i in range(8):
            self.t.undo()

    def redo(self):
        ''' redo something that was undone by undo(). '''
        if not self.undoActions:
            #error if there is nothing to redo
            self.popupmsg('Error!', 'There is nothing to redo!')
        redo = self.undoActions[-1]
        redo.draw()
        self.drawings.append(redo)
        self.undoActions.pop()

    def clickedCircle(self, x, y):
        ''' iterates through circles to see if they were clicked on '''
        for circle in self.drawings:
            circle.ifClicked(x, y)

    def popupmsg(self, alert, msg):
        ''' shows popup box to user to display message. Used for a welcome and error message. '''
        if alert == 'Error!': 
            # use .showwarning for errors
            # error is user tries to redo/undo and that isn't possible
            messagebox.showwarning(alert, msg)
        else:
            # use .showinfo for welcome
            messagebox.showinfo(alert, msg)
    

circleManager = CircleManager()
s = turtle.Screen()
s.listen() # allow click events on canvas

# click events
s.onclick(circleManager.addCircle, 1)
s.onkeypress(circleManager.undo, 'z')
s.onkeypress(circleManager.redo, 'y')
s.onkeypress(circleManager.reset, 'Escape')
s.onclick(circleManager.clickedCircle, 3)

turtle.mainloop()