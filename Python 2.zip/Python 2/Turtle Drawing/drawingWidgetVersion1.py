#This program is a simple drawing widget in turtle
#The user can click to draw a line to that point,
#drag the turtle itself, change color, draw a 
#square, triangle, or circle, and change the brush width
#They can also reset, undo, redo, and lift up the pen

from turtle import *
from tkinter import messagebox


class DrawingWidget():

    def __init__(self):
        self.colors = ['red', 'blue', 'orange', 'green', 'yellow', 'purple', 'pink', 'brown', 'black']
        self.shapes = ['square', 'circle', 'triangle']
        self.shapeButtons = []
        self.drawings = []
        self.undoActions = [] #for redoing action
        self.activeShape = None #detect whether shape is activitated
        self.startPoint = (0,0)
        self.currentColor = 'black'

    def createColorButtons(self):
        ''' This loops through the colors list, and creates a instance of
        ColorButton with the corresponding color and coordinates '''

        shapesize(1.5)
        self.setUpTurtle = Turtle()
        self.setUpTurtle.speed(0)
        self.setUpTurtle.penup()
        box = Box(-360, 300, self.setUpTurtle)
        box.draw()

        self.setUpTurtle.goto(-330, 237.5)
        self.setUpTurtle.write('Colors: ', align = 'center', font = ('Arial', 10, 'bold'))
        for i, color in enumerate(self.colors):
            btn = ColorButton(-260+70*i, 250, 30, color, self)
            btn.draw()

    def createShapeButtons(self):
        box = Box(-360, -200, self.setUpTurtle)
        box.draw()

        self.setUpTurtle.goto(-330, -250)
        self.setUpTurtle.write('Shapes: ', align = 'center', font = ('Arial', 10, 'bold'))
        for i,shape in enumerate(self.shapes):
            btn = ShapeButton(-260+70*i, -250, 30, shape, self)
            btn.draw()
            self.shapeButtons.append(btn)


    def createActionButtons(self):
        box = Box(-260, 200, self.setUpTurtle, 400, 100)
        self.setUpTurtle.right(90)
        box.draw()

        self.setUpTurtle.goto(-310, 180)
        self.setUpTurtle.write('Actions:', align = 'center', font = ('Arial', 10, 'bold'))

        for i in range(5):
            if i == 0:
                btn = ResetButton(-310, 140, 2, self)
                label = 'Reset!'
                symbol = '!'
            elif i == 1:
                btn = UndoButton(-310, 65, 2, self)
                label = 'Undo!'
                symbol = '↺'
            elif i == 2:
                btn = RedoButton(-310, -15, 2, self)
                label = 'Redo!'
                symbol = '↻'
            elif i == 3:
                btn = LiftPenButton(-310, -95, 2, self)
                label = 'Lift Pen!'
                symbol = '⬆'
            else:
                btn = EraserButton(-310, -175, 2, self)
                label = 'Eraser!'
                symbol = '⬒'

            self.setUpTurtle.goto(-310, 160-75*i)
            self.setUpTurtle.write(label, align = 'center', font=('Arial', 10, 'bold'))
            btn.draw()
            self.drawSymbol(-310, btn.y-25, 'red', symbol)

    def createBrushWidthButtons(self):
        box = Box(340, 200, self.setUpTurtle, 400, 100)
        box.draw()

        self.setUpTurtle.goto(290, 180)
        self.setUpTurtle.write('Brush Width!', align = 'center', font = ('Arial', 10, 'bold'))

        for i in range(5):
            btn = BrushWidthButton(290, 150-80*i, 2, self, 2+i*2)
            btn.draw()
            btn.drawBrushWidth()

        self.setUpTurtle.hideturtle()
        self.popupmsg('Welcome!', 'This is a simple drawing widget using turtle...')
        
    def drawSymbol(self, x, y, color, symbol):
        self.setUpTurtle.goto(x, y)
        self.setUpTurtle.pendown()
        self.setUpTurtle.color(color)
        self.setUpTurtle.write(symbol, align='center', font=('Arial', 30, 'bold'))
        self.setUpTurtle.color('black')
        self.setUpTurtle.penup()

    def popupmsg(self, alert, msg):
        if alert == 'Welcome!':
            messagebox.showinfo(alert, msg)
        else:
            messagebox.showerror(alert, msg)

    def onClick(self, x, y):
        if -200<y<200 and -260<x<240:
            if self.activeShape:
                stampedShape = Drawing(self.startPoint, (x,y), color(), self)
                stampedShape.stampShape()
                self.drawings.append(stampedShape)

            else:
                line = Drawing(pos(), (x, y), color(), self)
                line.gotoPoint()
                self.drawings.append(line)
        
        self.undoActions = []

    def onDrag(self, x, y):
        if -200<y<200 and -260<x<240:
            goto(x,y)

class Box():
    def __init__(self, x, y, turtle, length=700, width=100):
        self.x = x
        self.y = y
        self.length = length
        self.width = width
        self.turtle = turtle

    def draw(self):
        self.turtle.goto(self.x, self.y)
        self.turtle.pendown()
        for i in range(2):
            self.turtle.forward(self.length)
            self.turtle.right(90)
            self.turtle.forward(self.width)
            self.turtle.right(90)  
        self.turtle.penup()

class Button():
    def __init__(self, x, y, width, parentClass):
        self.x = x
        self.y = y
        self.width = width
        self.DrawingWidget = parentClass

    def draw(self, x, y, size, btn, color):
        btn.shapesize(size)
        btn.color(color)
        btn.penup()
        btn.goto(x, y)
        btn.showturtle()
        btn.stamp()

    
class ColorButton(Button):
    def __init__(self, x, y, width, color, parentClass):
        super().__init__(x, y, width, parentClass)
        self.color = color
        self.t = Turtle('circle', visible=None)

    def draw(self):
        self.t.shapesize(50/20)
        self.t.color(self.color)
        self.t.penup()
        self.t.goto(self.x, self.y)
        self.t.showturtle()
        self.t.stamp()

        self.t.onclick(lambda x, y: self.clickedButton(x, y))

    def clickedButton(self, x, y):
        colorChange = Drawing(pos(), pos(), self.color, self.DrawingWidget, color())
        self.DrawingWidget.drawings.append(colorChange)

        color(self.color)
        self.currentColor = self.color
        for shape in self.DrawingWidget.shapeButtons:
            shape.draw()



class ShapeButton(Button):
    def __init__(self, x, y, width, shape, parentClass):
        super().__init__(x, y, width, parentClass)
        self.shape = shape
        self.t = Turtle(self.shape, visible=None)

    def draw(self):
        self.t.shapesize(50/20)
        self.t.color(color()[0])
        self.t.penup()
        self.t.goto(self.x, self.y)
        self.t.showturtle()
        self.t.stamp()

        self.t.onclick(lambda x, y: self.clickedButton(x, y))

    def clickedButton(self, x, y):
        self.DrawingWidget.activeShape = self.shape
        self.DrawingWidget.startPoint = pos()


class ResetButton(Button):
    def __init__(self, x, y, width, parentClass):
        super().__init__(x, y, width, parentClass)

    def draw(self):

        btn = Turtle('square', visible = None)
        super().draw(self.x, self.y, self.width, btn, 'black')
        super().draw(self.x, self.y, self.width-.2, btn, 'white')
        
        btn.onclick(lambda x, y: self.clickedButton(x, y))
    
    def clickedButton(self, x, y):
        reset()
        self.DrawingWidget.currentColor = 'black'
        shapesize(1.5)
        for shape in self.DrawingWidget.shapeButtons:
            shape.draw()
        self.DrawingWidget.drawings=[]
        self.DrawingWidget.undoActions = []

class UndoButton(Button):
    def __init__(self, x, y, width, parentClass):
        super().__init__(x, y, width, parentClass)

    def draw(self):

        btn = Turtle('square', visible = None)
        super().draw(self.x, self.y, self.width, btn, 'black')
        super().draw(self.x, self.y, self.width-.2, btn, 'white')
        
        btn.onclick(lambda x, y: self.clickedButton(x, y))
    
    def clickedButton(self, x, y):
        if len(self.DrawingWidget.drawings) > 0:
            if self.DrawingWidget.drawings[-1].shape:
                for i in range(7):
                    undo()
            undo()

            if color() != self.DrawingWidget.currentColor:
                for shape in self.DrawingWidget.shapeButtons:
                    shape.draw()

            self.DrawingWidget.undoActions.append(self.DrawingWidget.drawings[-1])
            del self.DrawingWidget.drawings[-1]
        else:
            self.DrawingWidget.popupmsg('Error', 'There is nothing to undo!')

class RedoButton(Button):
    def __init__(self, x, y, width, parentClass):
        super().__init__(x, y, width, parentClass)
        
    def draw(self):
        btn = Turtle('square', visible=None)

        super().draw(self.x, self.y, self.width, btn, 'black')
        super().draw(self.x, self.y, self.width-.2, btn, 'white')

        btn.onclick(lambda x, y: self.clickedButton(x, y))

    def clickedButton(self, x, y):
        if len(self.DrawingWidget.undoActions) > 0:
            redo = self.DrawingWidget.undoActions[-1]
            if redo.shape:
                redo.stampShape()
                
                
            elif redo.originalColor:
                color(redo.color)
                if color() != self.DrawingWidget.currentColor:
                    self.DrawingWidget.currentColor = color()
                    for shape in self.DrawingWidget.shapeButtons:
                        shape.draw()
            else:   
                redo.gotoPoint()
            self.DrawingWidget.drawings.append(redo)
            del self.DrawingWidget.undoActions[-1]
        else:
            self.DrawingWidget.popupmsg('Error', 'There is nothing to redo!')
        

class LiftPenButton(Button):
    def __init__(self, x, y, width, parentClass):
        super().__init__(x, y, width, parentClass)
        self.timesClicked = 0

    def draw(self):
        btn = Turtle('square', visible = None)
        super().draw(self.x, self.y, self.width, btn, 'black')
        super().draw(self.x, self.y, self.width-.2, btn, 'white')
        
        btn.onclick(lambda x, y: self.clickedButton(x, y))
    
    def clickedButton(self, x, y):
        self.timesClicked += 1
        if self.timesClicked % 2 == 0:
            pendown()
        else:
            penup()
        self.DrawingWidget.drawings.append(Drawing(pos(), pos(), color(), self.DrawingWidget))

class EraserButton(Button):
    def __init__(self, x, y, width, parentClass):
        super().__init__(x, y, width, parentClass)
        self.timesClicked = 0

    def draw(self):
        btn = Turtle('square', visible = None)
        super().draw(self.x, self.y, self.width, btn, 'black')
        super().draw(self.x, self.y, self.width-.2, btn, 'white')
        
        btn.onclick(lambda x, y: self.clickedButton(x, y))

    def clickedButton(self, x, y):
        self.timesClicked += 1
        if self.timesClicked % 2 == 0:
            color(self.DrawingWidget.currentColor)
        else:
            color('white')

class BrushWidthButton(Button):
    def __init__(self, x, y, width, parentClass, brushWidth):
        super().__init__(x, y, width, parentClass)
        self.brushWidth = brushWidth

    def draw(self):
        btn = Turtle('square', visible=None)

        super().draw(self.x, self.y, self.width, btn, 'black')
        super().draw(self.x, self.y, self.width-.2, btn, 'white')

        btn.onclick(lambda x, y: self.clickedButton(x, y))

    def drawBrushWidth(self):
        self.DrawingWidget.setUpTurtle.goto(self.x, self.y+10)
        self.DrawingWidget.setUpTurtle.pensize(self.brushWidth)
        self.DrawingWidget.setUpTurtle.pendown()
        self.DrawingWidget.setUpTurtle.forward(20)
        self.DrawingWidget.setUpTurtle.penup()

    def clickedButton(self, x, y):
        pensize(self.brushWidth)

class Drawing():
    def __init__(self, start, end, color, parentClass, originalColor=None):
        self.start = start
        self.end = end
        self.originalColor = originalColor
        self.color = color
        self.DrawingWidget = parentClass
        self.shape = parentClass.activeShape

    def stampShape(self):
        hideturtle()
        shape(self.shape)
        shapesize(2)
        penup()
        goto(self.end)
        stamp()

        self.DrawingWidget.activeShape = None
        shape('classic')
        goto(self.start)
        pendown()
        showturtle()

    def gotoPoint(self):
        goto(self.end)

drawingWidget = DrawingWidget()
drawingWidget.createColorButtons()
drawingWidget.createShapeButtons()
drawingWidget.createActionButtons()
drawingWidget.createBrushWidthButtons()
s = Screen()

s.onclick(drawingWidget.onClick, 1)
ondrag(drawingWidget.onDrag)

s.listen()
s.mainloop()