import turtle
from random import randint, choice
from tkinter import messagebox

normal_font = ('Verdana', 10)

class Drawing_Circle:

    def __init__ (self):
        self.t = turtle.Turtle()
        self.popupmsg('Welcome!', 'With this program, a circle with a random color and radius will be drawn wherever you left-click.' + 
                        ' You can undo ("z" key) and redo ("y" key) actions while drawing, and you can right-click to reset the drawing board.')
        self.points = []
        self.actions = []
        self.undoActions = []
        self.colors = ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'black', 'brown', 'yellow', 'gold', 'orange', 'red', 'maroon', 'violet', 'magenta', 'purple', 'navy', 'blue', 'skyblue', 'cyan', 'turquoise', 'lightgreen', 'green', 'darkgreen', 'chocolate', 'brown', 'black', 'gray', 'gainsboro']
        self.drawings = []

    def render(self, x, y, color, radius):
        ''' draws circle on screen '''
        self.t.speed(8)
        self.t.penup()
        self.t.color(color)
        self.t.fillcolor(color)
        self.t.goto(x, y)
        self.t.pendown()
        self.t.begin_fill()
        self.t.circle(radius)
        self.t.end_fill()

    def addPoint(self, x, y, color, radius):
        ''' appends point clicked on to list '''
        self.drawings.append([x, y, color, radius])

    def addPointAndRender(self, x, y):
        ''' appends point and calls render() with random color and radius '''
        self.addPoint(x, y, choice(self.colors), randint(50, 150))
        self.undoActions = []
        self.t.reset
        self.render(self.drawings[-1][0], self.drawings[-1][1], self.drawings[-1][2], self.drawings[-1][3])

    def reset(self, x, y):
        ''' clears canvas and drawings from list. '''
        self.t.reset()
        self.drawings = []

    def undo(self):
        ''' undo the last thing drawn; will reset if there is only one circle. '''
        if not self.drawings:
            self.popupmsg('Error!', 'There is nothing to undo!')
        self.undoActions.append(self.drawings[-1])
        self.drawings.pop()
        for i in range(8):
            self.t.undo()

    def redo(self):
        ''' redo something that was undone by undo(). '''
        if not self.undoActions:
            self.popupmsg('Error!', 'There is nothing to redo!')
        redo = self.undoActions[-1]
        self.addPoint(redo[0], redo[1], redo[2], redo[3])
        self.render(redo[0], redo[1], redo[2], redo[3])
        self.undoActions.pop()

    def popupmsg(self, alert, msg):
        ''' shows popup box to user to display message. Used for a welcome and error message. '''
        if alert == 'Welcome!': 
            # use .showinfo for welcome
            messagebox.showinfo(alert, msg)
        else:
            # use .showwarning for errors
            messagebox.showwarning(alert, msg)

        

s = turtle.Screen()
s.listen()
drawingCircle = Drawing_Circle()

s.onclick(drawingCircle.addPointAndRender, 1)
s.onkeypress(drawingCircle.undo, 'z')
s.onkeypress(drawingCircle.redo, 'y')
s.onclick(drawingCircle.reset, 3)

turtle.mainloop()