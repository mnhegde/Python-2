#This program is a simple drawing widget in turtle
#The user can click to draw a line to that point,
#drag the turtle itself, change color, draw a 
#square, triangle, or circle, and change the brush width
#They can also reset, undo, redo, and lift up the pen

from turtle import *
from tkinter import messagebox


class DrawingWidget():

    def __init__(self):
        ''' This is where the the lists and variables for the overall drawing widget '''
        self.colors = ['red', 'blue', 'orange', 'green', 'yellow', 'purple', 'pink', 'brown', 'black']
        self.shapes = ['square', 'circle', 'triangle']
        self.shapeButtons = []
        self.actionAndBrushButtons = []
        self.drawings = []
        self.undoActions = [] #for redoing action
        self.activeShape = None #detect whether shape is activitated
        self.startPoint = (0,0)
        self.currentColor = 'black'

    def createColorButtons(self):
        ''' This loops through the colors list, and creates a instance of
        ColorButton with the corresponding color and coordinates '''

        shapesize(1.5)
        self.setUpTurtle = Turtle()
        self.setUpTurtle.speed(0)
        self.setUpTurtle.penup()
        box = Box(-360, 300, self.setUpTurtle)
        box.draw()

        self.setUpTurtle.goto(-330, 237.5)
        self.setUpTurtle.write('Colors: ', align = 'center', font = ('Arial', 10, 'bold'))
        for i, color in enumerate(self.colors):
            btn = ColorButton(-260+70*i, 250, 30, color, self)
            btn.draw() #each object has draw function

    def createShapeButtons(self):
        ''' This loops through the shapes list, and creates a instance of
        ShapeButton with the corresponding shape and coordinates '''

        box = Box(-360, -200, self.setUpTurtle)
        box.draw()

        self.setUpTurtle.goto(-330, -250)
        self.setUpTurtle.write('Shapes: ', align = 'center', font = ('Arial', 10, 'bold'))
        for i,shape in enumerate(self.shapes):
            btn = ShapeButton(-260+70*i, -250, 30, shape, self)
            btn.draw()
            self.shapeButtons.append(btn) #appended for later manipulation


    def createActionButtons(self):
        ''' Creates different actions for users, which include a reset,
        undo, redo, lift pen, and eraser button. Each of thee buttons have
        their own class, and corresponding labels and symbols. '''
        box = Box(-260, 200, self.setUpTurtle, 400, 100)
        self.setUpTurtle.right(90)
        box.draw()

        self.setUpTurtle.goto(-310, 180)
        self.setUpTurtle.write('Actions:', align = 'center', font = ('Arial', 10, 'bold'))
        
        self.setUpTurtle.left(90)

        for i in range(5):
            if i == 0:
                btn = ResetButton(-332.5, 155, 45, self)
                label = 'Reset!'
                symbol = '!'
            elif i == 1:
                btn = UndoButton(-332.5, 85, 45, self)
                label = 'Undo!'
                symbol = '↺'
            elif i == 2:
                btn = RedoButton(-332.5, 15, 45, self)
                label = 'Redo!'
                symbol = '↻'
            elif i == 3:
                btn = LiftPenButton(-332.5, -55, 45, self)
                label = 'Lift Pen!'
                symbol = '⬆'
            else:
                btn = EraserButton(-332.5, -125, 45, self)
                label = 'Eraser!'
                symbol = '⬒'

            self.setUpTurtle.goto(-310, 160-70*i)
            self.setUpTurtle.write(label, align = 'center', font=('Arial', 10, 'bold'))
            btn.draw()
            self.drawSymbol(-310, btn.y-40, 'red', symbol)
            self.actionAndBrushButtons.append(btn) 

    def createBrushWidthButtons(self):
        ''' Creates all buttons for changing brush width of turtle. Creates instance
        of BrushWidthButton with corresponding coordinates and brush width '''
        self.setUpTurtle.right(90)
        box = Box(340, 200, self.setUpTurtle, 400, 100)
        box.draw()

        self.setUpTurtle.goto(290, 180)
        self.setUpTurtle.write('Brush Width!', align = 'center', font = ('Arial', 10, 'bold'))
        self.setUpTurtle.left(90)

        for i in range(5):
            btn = BrushWidthButton(267.5, 155-70*i, 45, self, 2+i*2)
            btn.draw()
            btn.drawBrushWidth()
            self.actionAndBrushButtons.append(btn)

        self.setUpTurtle.hideturtle()
        self.popupmsg('Welcome!', 'This is a simple drawing widget using turtle. In this program, you can ' + 
            'click anywhere within the box to move the turtle, and you can grab the turtle to drag it as well. ' + 
            ' You can choose the color at the top, and choose a shape at the bottom, which will appear where you ' + 
            'click after it is selected. There are also actions, such as reseting the boarrd, undoing, redoing, ' + 
            'lifting the turtle, and using the eraser. Finally, you can change the pen width on the right!')
        pendown()
        
    def drawSymbol(self, x, y, color, symbol):
        ''' This function takes an x and y coordinate, color, and symbol, and writes this for the 
        action and brush width buttons. '''
        self.setUpTurtle.goto(x, y)
        self.setUpTurtle.pendown()
        self.setUpTurtle.color(color)
        self.setUpTurtle.write(symbol, align='center', font=('Arial', 25, 'bold'))
        self.setUpTurtle.color('black')
        self.setUpTurtle.penup()

    def popupmsg(self, alert, msg):
        ''' Displays message to user through messagebox from tkinter. Either shows
        welcome message, or errors in drawing widget (i.e. no undos or redos possible) '''
        if alert == 'Welcome!':
            messagebox.showinfo(alert, msg)
        else:
            messagebox.showerror(alert, msg)

    def onClick(self, x, y):
        ''' This runs all the actions when the user clicks. It checks whether it is
        in the right range for the coordinates, and then sees whether a shape has been selected '''
        if -200<y<200 and -260<x<240:
            if self.activeShape: #checks whether shape has been clicked
                stampedShape = Drawing(self.startPoint, (x,y), color(), self)
                stampedShape.stampShape()
                self.drawings.append(stampedShape)
            else: #if random point was clicked
                line = Drawing(pos(), (x, y), color(), self)
                line.gotoPoint()
                self.drawings.append(line)
                #create an object for actions for undo and redo functions
        
            self.undoActions = []
        else:
            for button in self.actionAndBrushButtons:
                if button.x<x<button.x+button.width and button.y-button.width<y<button.y:
                    #checks whether click was in any of the buttons
                    button.clickedButton()

                    #this doesn't use .onclick, as the symbols drawn prohibit the turtle from
                    #detecting a click, causing problems. This is why detecting the x,y for a click
                    #if used for these butttons

    def onDrag(self, x, y):
        ''' THis function allows the turtle to be dragged by the user '''
        if -200<y<200 and -260<x<240: #prohibits user from dragging it out of boundaries
            goto(x,y)

class Box():
    def __init__(self, x, y, turtle, length=700, width=100):
        ''' This class is for each of the boxs that house the different buttons '''
        self.x = x
        self.y = y
        self.length = length
        self.width = width
        self.turtle = turtle

    def draw(self):
        ''' This draws the box with the respective x, y, length, and width '''
        self.turtle.goto(self.x, self.y)
        self.turtle.pendown()
        for i in range(2):
            self.turtle.forward(self.length)
            self.turtle.right(90)
            self.turtle.forward(self.width)
            self.turtle.right(90)  
        self.turtle.penup()

class Button():
    def __init__(self, x, y, width, drawingWidet):
        ''' This is the parent class for all the types of buttons in the 
        drawing widget. It has the standard attributes, such as the x and y
        coordinate, the width, and the DrawingWidget '''
        self.x = x
        self.y = y
        self.width = width
        self.DrawingWidget = drawingWidget

    def draw(self, x, y, width):
        ''' This draws the button, and is the default function. This doesn't
        make each button a turtle, but just draws a box '''
        self.DrawingWidget.setUpTurtle.goto(x,y)
        self.DrawingWidget.setUpTurtle.pendown()
        for i in range(4):
            self.DrawingWidget.setUpTurtle.forward(width)
            self.DrawingWidget.setUpTurtle.right(90)
        self.DrawingWidget.setUpTurtle.penup()


    
class ColorButton(Button):
    def __init__(self, x, y, width, color, drawingWidth):
        ''' THic class is for all the color buttons. It gets the attributes from
        the class Button, but also has a color attribut and creates a turtle for 
        each button. This allows the .onclick function to be used '''
        super().__init__(x, y, width, drawingWidth)
        self.color = color
        self.t = Turtle('circle', visible=None)

    def draw(self):
        ''' Since each button is a turtle object, they are stamped with their 
        corresponding coordinates '''
        self.t.shapesize(50/20)
        self.t.color(self.color)
        self.t.penup()
        self.t.goto(self.x, self.y)
        self.t.showturtle()
        self.t.stamp()

        self.t.onclick(lambda x, y: self.clickedButton(x, y))

    def clickedButton(self, x, y):
        ''' This function runs when the color button is clicked. This changes 
        the color of the turtle, and redraws the shapeButtons to reflect the color
        change. '''
        colorChange = Drawing(pos(), pos(), self.color, self.DrawingWidget, color())
        self.DrawingWidget.drawings.append(colorChange)

        color(self.color)
        self.currentColor = self.color
        for shape in self.DrawingWidget.shapeButtons:
            shape.draw()

class ShapeButton(Button):
    def __init__(self, x, y, width, shape, drawingWidget):
        ''' This inherits all the attributes from Button, but also has
        a shape attribute and each button is a turtle object. '''
        super().__init__(x, y, width, drawingWidget)
        self.shape = shape
        self.t = Turtle(self.shape, visible=None)

    def draw(self):
        ''' Since each object is a turtle, they can be stamped. '''
        self.t.shapesize(50/20)
        self.t.color(color()[0])
        self.t.penup()
        self.t.goto(self.x, self.y)
        self.t.showturtle()
        self.t.stamp()

        self.t.onclick(lambda x, y: self.clickedButton(x, y))

    def clickedButton(self, x, y):
        ''' This is run when a shape is clicked. The shape is assigned to
        the activeShape attribute, and the position of the turtle in this 
        moment is stored for future use. '''
        self.DrawingWidget.activeShape = self.shape
        self.DrawingWidget.startPoint = pos()


class ResetButton(Button):
    def __init__(self, x, y, width, drawingWidget):
        ''' This inherits the attributes from Button. '''
        super().__init__(x, y, width, drawingWidget)

    def draw(self):
        ''' This uses the draw function from Button, as it isn't a turtle
        object, but rather just a drawn box '''
        penup()
        super().draw(self.x, self.y, self.width)
        
    
    def clickedButton(self):
        ''' This resets the turtle the user is controlling when clicked. It
        also redraws the shapeButtons to reflect the change to the color black.
        It clears all the lists where drawings were stored as well. '''
        reset()
        self.DrawingWidget.currentColor = 'black'
        shapesize(1.5)
        for shape in self.DrawingWidget.shapeButtons:
            shape.draw()
        self.DrawingWidget.drawings=[]
        self.DrawingWidget.undoActions = []

class UndoButton(Button):
    def __init__(self, x, y, width, drawingWidget):
        ''' This inherits the attributes from Button. '''
        super().__init__(x, y, width, drawingWidget)

    def draw(self):
        ''' This uses the draw function from Button, as it isn't a turtle
        object, but rather just a drawn box '''
        penup()
        super().draw(self.x, self.y, self.width)
    
    def clickedButton(self):
        ''' This runs when the undoButton is clicked. The drawings list stores
        everything the user has done. It gets the last item and undoes it, and undoes
        itself 7 times if a shape was drawn. Then it checks for a color change for the shape
        Buttons, and also adds this undone action to the undoActions list '''
        #there are some errors with undoing, as the turtle can lag and cause problems with tracking
        #actions by the user
        if len(self.DrawingWidget.drawings) > 0:
            if self.DrawingWidget.drawings[-1].shape:
                for i in range(7):
                    undo()
            undo()

            if color() != self.DrawingWidget.currentColor:
                self.DrawingWidget.currentColor = color()
                for shape in self.DrawingWidget.shapeButtons:
                    shape.draw()

            self.DrawingWidget.undoActions.append(self.DrawingWidget.drawings[-1])
            del self.DrawingWidget.drawings[-1]
        else:
            #returns error is list is empty
            self.DrawingWidget.popupmsg('Error', 'There is nothing to undo!')

class RedoButton(Button):
    def __init__(self, x, y, width, drawingWidget):
        ''' This inherits the attributes from Button. '''
        super().__init__(x, y, width, drawingWidget)
        
    def draw(self):
        ''' This uses the draw function from Button, as it isn't a turtle
        object, but rather just a drawn box '''
        penup()
        super().draw(self.x, self.y, self.width)

    def clickedButton(self):
        if len(self.DrawingWidget.undoActions) > 0:
            redo = self.DrawingWidget.undoActions[-1]
            if redo.shape:
                redo.stampShape()
                
            elif redo.originalColor:
                color(redo.color)
                if color() != self.DrawingWidget.currentColor:
                    #redraws buttons if color changes
                    self.DrawingWidget.currentColor = color()
                    for shape in self.DrawingWidget.shapeButtons:
                        shape.draw()
            else:   
                redo.gotoPoint()
            self.DrawingWidget.drawings.append(redo)
            del self.DrawingWidget.undoActions[-1]
        else:
            self.DrawingWidget.popupmsg('Error', 'There is nothing to redo!')
        

class LiftPenButton(Button):
    def __init__(self, x, y, width, drawingWidget):
        ''' This inherits the attributes from Button. '''
        super().__init__(x, y, width, drawingWidget)
        self.timesClicked = 0 #track whether pen is up or down

    def draw(self):
        ''' This uses the draw function from Button, as it isn't a turtle
        object, but rather just a drawn box '''
        penup()
        super().draw(self.x, self.y, self.width)
    
    def clickedButton(self):
        ''' This tracks whether the pen is up or down by checking the
        times it has been clicked '''
        self.timesClicked += 1 #allows it to alternate by checking odd or even
        if self.timesClicked % 2 == 0:
            pendown()
        else:
            penup()
        self.DrawingWidget.drawings.append(Drawing(pos(), pos(), color(), self.DrawingWidget))
        #adds it to list so it can be tracked for undoing

class EraserButton(Button):
    def __init__(self, x, y, width, drawingWidget):
        ''' This inherits the attributes from Button. '''
        super().__init__(x, y, width, drawingWidget)
        self.timesClicked = 0

    def draw(self):
        ''' This uses the draw function from Button, as it isn't a turtle
        object, but rather just a drawn box '''
        penup()
        super().draw(self.x, self.y, self.width)

    def clickedButton(self):
        ''' Tracks whether eraser is active or not based on number of clicks '''
        self.timesClicked += 1 #uses odd or even to know if it's active
        if self.timesClicked % 2 == 0:
            color(self.DrawingWidget.currentColor)
        else:
            color('white')

class BrushWidthButton(Button):
    def __init__(self, x, y, width, drawingWidget, brushWidth):
        ''' This inherits the attributes from Button. It has a corresponding
        brushWidth attribute'''
        super().__init__(x, y, width, drawingWidget)
        self.brushWidth = brushWidth #for drawing symbol and changing turtle

    def draw(self):
        ''' This uses the draw function from Button, as it isn't a turtle
        object, but rather just a drawn box '''
        penup()
        super().draw(self.x, self.y, self.width)

    def drawBrushWidth(self):
        ''' This draws the symbol for each box of the brushWidth, using the 
        coordinates and the burhsWidt for the respective button '''
        self.DrawingWidget.setUpTurtle.right(90)
        self.DrawingWidget.setUpTurtle.goto(self.x+22.5, self.y-12.5)
        self.DrawingWidget.setUpTurtle.pensize(self.brushWidth)
        self.DrawingWidget.setUpTurtle.pendown()
        self.DrawingWidget.setUpTurtle.forward(20)
        self.DrawingWidget.setUpTurtle.pensize(1)
        self.DrawingWidget.setUpTurtle.penup()
        self.DrawingWidget.setUpTurtle.left(90)

    def clickedButton(self):
        ''' When clicked, the ensize will be changed to the instance's brushWidth '''
        pensize(self.brushWidth)

class Drawing():
    def __init__(self, start, end, color, drawingWidget, originalColor=None):
        ''' This object is used for undoing and redoing, and tracks everything the user has done.
        It assigns the start and end point, whether the color was changed, and whether the shape was changed.'''
        self.start = start
        self.end = end
        self.originalColor = originalColor
        self.color = color
        self.DrawingWidget = drawingWidget
        self.shape = drawingWidget.activeShape

    def stampShape(self):
        ''' This is called for stamping the shape where the user clicks. Each shape is the main turtle
        getting it's shape changed and stamping at the point clicked. '''
        hideturtle()
        shape(self.shape)
        shapesize(2)
        penup()
        goto(self.end)
        stamp()

        self.DrawingWidget.activeShape = None
        shape('classic')
        shapesize(1.5)
        goto(self.start)
        pendown()
        showturtle()

    def gotoPoint(self):
        ''' When redoing for a click, this makes the turtle go back to its end point '''
        goto(self.end)

drawingWidget = DrawingWidget()
drawingWidget.createColorButtons()
drawingWidget.createShapeButtons()
drawingWidget.createActionButtons()
drawingWidget.createBrushWidthButtons()
s = Screen()

s.onclick(drawingWidget.onClick, 1) #called when left button clicked
ondrag(drawingWidget.onDrag) #called when turtle is dragged

s.listen()
s.mainloop()