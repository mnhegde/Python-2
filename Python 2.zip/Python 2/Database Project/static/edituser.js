fetch ('/api/edituser')
.then (function (response) {
    return response.json();
})
.then (function (myJson) {
    firstname = document.getElementById('firstname')
    lastname = document.getElementById('lastname')

    fullname = myJson.split(' ')

    firstname.value = fullname[0]
    lastname.value = fullname[1]
})


function EditUser(event) {
    event.preventDefault();

    fullname = [document.getElementById('firstname').value, document.getElementById('lastname').value]
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/editusermodal');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(fullname, null, ' '))
}


form = document.getElementById('form');
form.addEventListener('submit', EditUser(event))