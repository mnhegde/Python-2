



function searchResult() {
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/api/users');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(document.getElementById('usersearch').value, null, ' '))

}


searchButton = document.getElementById('searchbutton')
searchButton.addEventListener('click', searchResult)