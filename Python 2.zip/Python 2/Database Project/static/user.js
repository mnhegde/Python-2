fetch('/api/users')
.then(function (response) {
    return response.json();
})
.then(function (myJson) {
    for(i=0; i<Object.keys(myJson).length; i++) {
            user = document.createElement('h4');
            user.appendChild(document.createTextNode(myJson[`User ${i+1}`]));

            section = document.createElement('div');
            section.setAttribute('class', 'ui container');
            section.appendChild(user);
            

            btn = document.createElement('button');
            btn.innerText = 'Edit'
            btn.setAttribute('id', myJson[`User ${i+1}`]);
            btn.setAttribute('onClick', 'editUser(this)');
            section.appendChild(btn);

            deletebtn = document.createElement('button');
            deletebtn.innerText = 'Delete'
            deletebtn.setAttribute('id', myJson[`User ${i+1}`]);
            deletebtn.setAttribute('onClick', 'showMessage(this)');
            section.appendChild(deletebtn);

            document.body.appendChild(section)
        }

    })

let selectedUser

function showMessage(button) {
    console.log(button.getAttribute('id'))

    selectedUser = button.getAttribute('id')

    message = document.getElementsByClassName('deleteModal')[0];
    message.style.display = 'block';
}

function deleteUser() {
    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/deleteuser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(selectedUser, null, ' '));

    cancel()

}

function cancel() {
    message = document.getElementsByClassName('deleteModal')[0];
    message.style.display = 'none'
}

function editUser(button) {
    console.log(button.getAttribute('id'))

    const xhr = new XMLHttpRequest;
    xhr.open('POST', '/edituser');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(button.getAttribute('id'), null, ' '));

    location = '/edituser'
}

function hello(msg, button) {
    console.log(msg + ' ' + button.getAttribute('id'))
}