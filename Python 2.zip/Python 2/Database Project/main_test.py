import unittest
import main, random


class TestDatabase(unittest.TestCase):

    #def test_addUser(self):
        #firstname = input('Enter firstname: ')
        #lastname = input('Enter lastname: ')
        #user = main.User(firstname=firstname, lastname=lastname)

        #db = main.db

        #db.session.add(user)
        #db.session.commit()

        #result = db.session.query(main.User).all()

        #self.assertEqual(result[-1].firstname, firstname)

    def test_editUser(self):
        db = main.db
        users = db.session.query(main.User).all()
        number = random.randint(0, len(users)-1)
        user = users[number]
        userinput = input('Enter user: ')
        
        user = main.EditUser(firstname=users[number].firstname, lastname=users[number].lastname)

        db.session.add(user)
        db.session.commit()

        editeduser = db.session.query(main.EditUser).all()
        originaluser = db.session.query(main.User).filter(main.User.firstname==editeduser.first, main.User.lastname==editeduser.last)
        print(originaluser)
        db.session.delete(originaluser)
        db.session.add(main.User(firstname=userinput.split(' ')[0], lastname=userinput.split(' ')[1]))
        db.session.commit()

        result = db.session.query(main.User).all()

        self.assertEqual(result[-1].firstname, userinput.split(' ')[0])

    #def test_deleteUser(self):
        #db = main.db
        #users = db.session.query(main.User).all()
        #number = random.randint(0, len(users)-1)
        #user = users[number]
        #print(user.firstname)

        #deletedUser = db.session.query(main.User).filter(main.User.firstname==user.firstname, main.User.lastname==user.lastname).first()

        #self.assertEqual(user, deletedUser)


if __name__ == '__main__':
    unittest.main()
