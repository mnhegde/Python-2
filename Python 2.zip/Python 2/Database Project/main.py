from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

app = Flask(__name__)

app.config['SECRET_KEY'] = 'hello'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    date_created = db.Column(db.DateTime, default=datetime.now)

class EditUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    date_created = db.Column(db.DateTime, default=datetime.now)

def getUsers():
    users = db.session.query(User).all()
    user_info = {}
    for i in range(len(users)):
        user_info['User %s' %(i+1)] = users[i].firstname.title() + ' ' + users[i].lastname.title()
    return json.dumps(user_info)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/users')
def users():
    return render_template('users.html')

@app.route('/adduser', methods=['GET', 'POST'])
def addPerson():
    if request.method == 'POST':
        data = request.json
        user = User(firstname=data[0], lastname=data[1])
        db.session.add(user)
        db.session.commit()
    else:
        return render_template('adduser.html')

@app.route('/edituser', methods=['GET', 'POST'])
def edituser():
    if request.method == 'POST':
        data = request.json
        editUser = EditUser(first=data.split(' ')[0], last=data.split(' ')[1])
        db.session.add(editUser)
        db.session.commit()
    else:
        return render_template('edituser.html')


@app.route('/editusermodal', methods=['GET', 'POST'])
def editusermodel():
    if request.method == 'POST':
        data = request.json
        print(data)
        originaluser = db.session.query(EditUser).all()
        print(originaluser)
        user = db.session.query(User).\
            filter_by(User.firstname == originaluser.first and User.lastname == originaluser.last)
        db.session.add(User(firstname=data[0], lastname=data[1]))
        db.session.delete(user)
        db.session.commit()


@app.route('/deleteuser', methods=['GET', 'POST'])
def deleteuser():
    if request.method=='POST':
        data = request.json
        deleteUser = db.session.query(User).\
            filter(User.firstname==data.split(' ')[0], User.lastname==data.split(' ')[1])
        

        #data = request.json
        #deleteuser = DeleteUser(first=data.split(' ')[0], last=data.split(' ')[1])
        #db.session.add(deleteuser)
        #db.session.commit()
    else:
        return render_template('delete.html')


@app.route('/addusermodal', methods=['GET', 'POST'])
def addUserModal():
    return render_template('addusermodal.html')

@app.route('/removeuser')
def removeUser():
    return render_template('removeuser.html')

@app.route('/api/users', methods=['GET', 'POST'])
def usersearch():
    if request.method == 'POST':
        data = request.json
        return data
    else:
        users = getUsers() 
        return users

@app.route('/api/edituser')
def editUserName():
    user = db.session.query(EditUser).all()
    return json.dumps(user[0].user)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)