# This is a 2 player tic tac toe game
# The code is dependent on the fact that the board is 3 X 3

board = ['_'] * 9
winner = ' '

def printBoard():
    ''' Prints out the tic tac toe board '''
    print('' + board[0] + '|' + board[1] + '|' + board[2])
    print('' + board[3] + '|' + board[4] + '|' + board[5])
    print('' + board[6] + '|' + board[7] + '|' + board[8])

def result():
    ''' Checks to see if player won horizontally, vertically, and diagonally '''
    for i in range(0, 7, 3):
        # checks whether any rows are completed
        if board[i] == 'X' or board[i] == 'O':
            if board[i] == board[i+1] == board[i+2]:
                return board[i]

    for i in range(0, 3):
        # checks whether any columns are completed
        if board[i] == 'X' or board[i] == 'O':
            if board[i] == board[i+3] == board[i+6]:
                return board[i]

    for i in range(0, 3, 2):
        # checks whether diagonals are completed
        if board[i] == 'X' or board[i] == 'O':
            if i == 0:
                if board[i] == board[4] == board[8]:
                        return board[i]
            elif i == 2:
                if board[i] == board[4] == board[6]:
                    return board[i]
    if '_' not in board:
        # returns draw if all spaces are filled
        return 'draw'
    return False

def whoIsWinner():
    ''' check for winner or draw '''
    if winner == 'X':
        print(player_one.title() + ' is the winner!')
    elif winner == 'O':
        print(player_two.title() + ' is the winner!')
    else:
        print('Neither player won. It was a draw!')   

while board:   
    board = ['_'] * 9    
    print('\nWelcome to Tic Tac Toe! Before we start, we need to figure out a few things: ')
    player_one = input('Who will be crosses? ').strip()
    player_two = input('Who will be naughts? ').strip()
    print('Welcome ' + player_one.title() + ' and ' + player_two.title() + '!')
    print('The spaces range from 0 to 8, with the 0 being the top-left space and the numbers increasing ' + 
            'as you go left to right. \nThe underscores represent an open space.')

    printBoard()
    print(player_one.title() + ' will start!')
    current_player = player_one

    while '_' in board:
        player_move = int(input('Pick a number from 0-8: '))
        if player_move < 0 or player_move > 8:
            print('That isn\'t in the right range! Pick again')
            continue
        if board[player_move] == '_':
            if current_player == player_two:
                board[player_move] = 'O'
                current_player = player_one
            else:
                current_player = player_two
                board[player_move] = 'X'
        else:
            print('That space is already taken! Pick again')
            continue 

        printBoard()
        who_won = result()
        if who_won:
            winner = who_won
            break
        else:
            continue

    print('\nThe game is finished!')
    whoIsWinner()
    
    flag = False
    while not flag:
        play_again = input('\nWant to play another game (y for yes or n for no)? ')
        if play_again == 'y' or play_again == 'n':
            flag = True

    if play_again == 'n':
        print('\nOkay, thanks for playing!')
        break
    else:
        continue