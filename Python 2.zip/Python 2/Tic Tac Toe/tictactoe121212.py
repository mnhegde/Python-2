# Tictactoe obect-oriented where user
#can choose between text and turtle game

from turtle import Turtle, Screen
from tkinter import messagebox

class TicTacToeText():
    #class for text game
    def __init__ (self, playerone, playertwo, board):
        self.playerone = playerone
        self.playertwo = playertwo
        self.board = board

        self.intro()

    def intro(self):
        '''Prints intro of game '''
        print('Welcome ' + self.playerone.title() + ' and ' + self.playertwo.title() + '!')
        print('The spaces range from 0 to 8, with the 0 being the top-left space and the numbers increasing ' + 
                'as you go left to right. \nThe underscores represent an open space.\n')
        print(self.playerone.title() + ' will start!')

    def printBoard(self, board):
        '''Prints board '''
        for j in range(3):
            for i in range(3):
                if i == 2:
                    #will move to next row
                    print(board[j][i], end = None )
                else:
                    #will print item on same line
                    print(board[j][i], end = '') #with end = ''
                    print('|', end = '')

    def playermove(self, currentplayer, checkResult):
        '''Asks player for move, and then changes board accordingly '''
        self.printBoard(self.board)
        playermove = int(input('Pick a number from 0 to 8: '))
        if playermove < 0 or playermove > 8:
            print('not the right range!')
            self.playermove(currentplayer, checkResult)
        
        for i in range(3):
            #converts playermove to row and space number
            if i <= playermove/3 <= i+1:
                row = i
                space = playermove - row*3
        if self.board[row][space] == '_':
            #checks if space is taken
            if currentplayer == self.playerone:
                self.board[row][space] = 'X' #marks space
                if not checkResult('X'):
                    #returns False if no one wins; calls next move
                    self.playermove(self.playertwo, checkResult)
            else:
                self.board[row][space] = 'O'
                if not checkResult('O'):
                    self.playermove(self.playerone, checkResult)
        else:
            print('That space is already taken!')
            self.playermove(currentplayer, checkResult)


class TicTacToe():
    def __init__ (self):
        self.board = [['_'] * 3 for i in range(3)] #creates list of board

        self.playerone = input('\nWho will be crosses? ').strip()
        self.playertwo = input('Who will be naughts? ').strip()
        self.current_player = self.playerone

        self.gameType()

        if self.Type == 'text':
            #calls playerturn for text game
            self.playerturn()
        else:
            #calls printboard for turtle
            self.game.printBoard(self.checkResult)
            self.s.mainloop()

    def gameType(self):
        #determines whether text or turtle game is used
        while True:
            self.Type = input('What type of tictactoe do you want to play? \nType "text" for the text ' + 
                    'game version and "turtle" for the turtle version: ')
            if self.Type == 'text' or self.Type == 'turtle':
                break
        if self.Type == 'text':
            self.game = TicTacToeText(self.playerone, self.playertwo, self.board)
        else:
            print('Click on the turtle tab at the bottom to start the game!')
            self.s = Screen()
            self.game = TicTacToeTurtle(self.playerone, self.playertwo, self.board)

    def playerturn(self):
        ''' calls text game playermove() '''
        self.game.playermove(self.current_player, self.checkResult)
    
    def popupmsg(self, alert, msg):
        ''' displays popup for turtle screen '''
        messagebox.showinfo(alert, msg)

    def checkResult(self, value):
        ''' Checks if there is a winner '''
        for j in range(3):
            #checks for winner by rows
            if self.board[j].count(value) == len(self.board[j]):
                self.winner(value)
                return True
            for i in range(3):
                if j == 0:
                    #checks for winner in columns
                    if self.board[j][i] == self.board[j+1][i] == self.board[j+2][i] and self.board[j][i] == value:
                        self.winner(value)
                        return True 
                    #checks for diagonal from top-left
                    if self.board[j][0] == self.board[j+1][1] == self.board[j+2][2] and self.board[j][0] == value:
                        self.winner(value)
                        return True
                    #checks for diagonal from top-right
                    if self.board[j][2] == self.board[j+1][1] == self.board[j+2][0] and self.board[j][2] == value:
                        self.winner(value)
                        return True
        spaces = []
        for rows in self.board:
            for space in rows:
                spaces.append(space)
        if spaces.count('X') + spaces.count('O') == len(spaces):
            #returns draw if all spaces are taken
            self.winner('draw')
            return True
        return False

    def winner(self, value):
        if value == 'X':
            gameWinner = self.playerone.title() + ' is the winner!'
        elif value == 'draw':
            gameWinner = 'It is a draw!'
        else:
            gameWinner = self.playertwo.title() + ' is the winner!'

        if self.Type == 'text':
            print('\n***WINNER****')
            self.game.printBoard(self.board)
            print(gameWinner)
        else:
            self.popupmsg('Winner!', gameWinner)
        self.playAgain()

    def playAgain(self):
        while True:
            #asks user until they answer yes ro no
            playAgain = input('Do you want to play again? "y" for yes and "n" for no ')
            if playAgain == 'y' or playAgain == 'n':
                break
        if playAgain == 'n':
            print('Okay, thanks for playing!')
            if self.Type == 'turtle':
                self.s.bye() #destroys screen
        else:
            self.game.board = [['_']*3 for i in range(3)]
            if self.Type == 'turtle':
                #resets whole game self.s.bye()
                self.s.reset()
                self.game.printBoard(self.checkResult)
            else:
                #this just resets the board
                print(self.playerone.title() + ' will start!')
                self.game.playermove(self.playerone, self.checkResult)
            # this resets the whole game self.__init__()

class TicTacToeTurtle():
    def __init__ (self, playerone, playertwo, board):
        self.playerone = playerone
        self.playertwo = playertwo
        self.currentplayer = self.playerone
        self.board = board
        self.Type = 'turtle'

        self.SQUARESIZE = 100
        self.FONTSIZE = 40
        self.FONT = ('Arial', self.FONTSIZE, 'bold')

    def printBoard(self, checkResult):
        background = Turtle('square')
        background.shapesize(self.SQUARESIZE * 3/20)
        background.color('black')
        background.stamp()
        background.hideturtle()

        for j in range(3):
            for i in range(3):
                space = Turtle('square', visible = False)
                space.shapesize(self.SQUARESIZE/20)
                space.color('white')
                space.penup()
                space.goto(i * (self.SQUARESIZE + 2) - (self.SQUARESIZE + 2), j * (self.SQUARESIZE + 2) - (self.SQUARESIZE + 2))
                space.showturtle()
                space.stamp()

                self.board[j][i] = space
                space.onclick(lambda x, y, space=space, i=i, j=j: self.spaceClicked(space, i, j, checkResult))

    def spaceClicked(self, space, i, j, checkResult):
        space.onclick(None)
        space.hideturtle()
        space.color('black')
        space.sety(space.ycor() - self.FONTSIZE/1.25)
        if self.currentplayer == self.playerone:
            value = 'X'
            space.write(value, align = 'center', font = self.FONT)
            self.board[j][i] = value
            self.currentplayer = self.playertwo
        else:
            value = 'O'
            space.write(value, align = 'center', font = self.FONT)
            self.board[j][i] = value
            self.currentplayer = self.playerone
        
        checkResult(value)

tictactoe = TicTacToe()