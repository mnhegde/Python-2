# Tictactoe obect-oriented where user
# can choose between text and turtle game

from turtle import Turtle, Screen
from tkinter import messagebox

class TicTacToe():
    # houses functions both tictactoe versions share and manages game
    def __init__ (self):
        self.board = [['_'] * 3 for i in range(3)]
        self.playerone = input('\nWho will be crosses? ').strip()
        self.playertwo = input('Who will be naughts? ').strip()
        self.current_player = self.playerone
        self.gameType()

    def gameType(self):
        ''' Sees whether text or turtle game is played and creates instance accordingly, 
            and calls appropiate functions'''
        while True:
            self.Type = input('What type of tictactoe do you want to play? \nType "text" for the text ' + 
                    'game version and "turtle" for the turtle version: ')
            if self.Type == 'text' or self.Type == 'turtle':
                break
        if self.Type == 'text':
            self.game = TicTacToeText(self.playerone, self.playertwo, self.board) #creates text game object
            self.game.playermove(self.checkResult)
        else:
            print('Click on the turtle tab below to start the game!')
            self.s = Screen()
            self.game = TicTacToeTurtle(self.playerone, self.playertwo, self.board) #creates turtle game object
            self.game.printBoard(self.checkResult)
            self.s.mainloop()
    
    def popupmsg(self, alert, msg):
        ''' Displays popup message in turtle '''
        messagebox.showinfo(alert, msg)

    def checkResult(self, value):
        ''' Checks if there is winner. It checks the rows first
            then the columns, and then the diagonals from the top-left
            space and top-right space. It checks for a draw by adding the
            spaces to a list and seeing if there are free spaces left. If any 
            are true, it retuns true, otherwise returns False '''
        for j in range(3):
            if self.board[j].count(value) == len(self.board[j]): #checks for rows
                self.winner(value)
                return True
            for i in range(3):
                if j == 0:
                    if self.board[j][i] == self.board[j+1][i] == self.board[j+2][i] and self.board[j][i] == value: #checks for columns
                        self.winner(value)
                        return True 
                    if self.board[j][0] == self.board[j+1][1] == self.board[j+2][2] and self.board[j][0] == value: #checks for diagonal from top-left
                        self.winner(value)
                        return True
                    if self.board[j][2] == self.board[j+1][1] == self.board[j+2][0] and self.board[j][2] == value: #checks for diagonal from top-right
                        self.winner(value)
                        return True
        spaces = []
        for rows in self.board:
            for space in rows:
                spaces.append(space) #stores value of spaces
        if spaces.count('X') + spaces.count('O') == len(spaces):
            self.winner('draw')
            return True

        return False #if no winner to continue turn

    def winner(self, value):
        ''' Displays winner of game ''' 
        if value == 'X':
            gameWinner = self.playerone.title() + ' is the winner!'
        elif value == 'draw':
            gameWinner = 'It is a draw!'
        else:
            gameWinner = self.playertwo.title() + ' is the winner!'

        if self.Type == 'text':
            print('\n***WINNER****')
            self.game.printBoard(self.board)
            print(gameWinner)
        else:
            self.popupmsg('Winner!', gameWinner)
        self.playAgain()

    def playAgain(self):
        ''' Whether user wants to play again '''
        if self.Type == 'text':
            while True:
                playAgain = input('Do you want to play again? "y" for yes and "n" for no ')
                if playAgain == 'y' or playAgain == 'n':
                    break
            if playAgain == 'n':
                print('Okay, thanks for playing!')
            else:
                self.__init__()
        else:
            #messagebox.askquestion has yes and no button that can run functions 
            if messagebox.askquestion('Play again?', 'Do you want to play again?') == 'yes':
                #error with turtle game if yes. printBoard() doesn't work
                #if player chooses turtle game again
                self.popupmsg('Restarting!', 'Ok, restarting the game!')
                self.s.bye() #destroys screen
                self.__init__()
            else:
                self.popupmsg('End game!', 'Ok, thanks for playing!')
                self.s.bye()

class TicTacToeText():
    def __init__ (self, playerone, playertwo, board):
        self.playerone = playerone
        self.playertwo = playertwo
        self.currentplayer = self.playerone
        self.board = board

        self.intro()

    def intro(self):
        '''Prints intro to game '''
        print('Welcome ' + self.playerone.title() + ' and ' + self.playertwo.title() + '!')
        print('The spaces range from 0 to 8, with the 0 being the top-left space and the numbers increasing ' + 
                'as you go left to right. \nThe underscores represent an open space.\n')
        print(self.playerone.title() + ' will start!')

    def printBoard(self, board):
        '''Prints board '''
        for j in range(3):
            for i in range(3):
                if i == 2:
                    #will move to next row when printing next item
                    print(board[j][i], end = None )
                else:
                    #will print item on same line
                    print(board[j][i], end = '') #with end = ''
                    print('|', end = '')

    def playermove(self, checkResult):
        '''Asks player for move in the space. Checks whether it is
        taken, then marks space accordingly. If number isn't in range
        or the space is taken, prints message and reruns function '''
        self.printBoard(self.board)
        playermove = int(input('Pick a number from 0 to 8: '))
        if playermove < 0 or playermove > 8:
            print('Not the right range!')
            self.playermove(checkResult)
        
        for i in range(3):
            #converts playermove to row and space number for indexing
            if i <= playermove/3 <= i+1:
                row = i
                space = playermove - row*3
        if self.board[row][space] == '_': #if space is free
            if self.currentplayer == self.playerone:
                self.board[row][space] = 'X' #marks space
                if not checkResult('X'):
                    #returns False is no winner
                    self.currentplayer = self.playertwo
                    self.playermove(checkResult)
            else:
                self.board[row][space] = 'O'
                if not checkResult('O'):
                    self.currentplayer = self.playerone
                    self.playermove(checkResult)
        else:
            print('That space is already taken!')
            self.playermove(checkResult)

class TicTacToeTurtle():
    def __init__ (self, playerone, playertwo, board):
        self.playerone = playerone
        self.playertwo = playertwo
        self.currentplayer = self.playerone
        self.board = board
        self.SQUARESIZE = 100
        self.FONTSIZE = 40
        self.FONT = ('Arial', self.FONTSIZE, 'bold')

    def printBoard(self, checkResult):
        ''' Creates board with turtles in each space to detect click
            by user '''
        #creates whole board as rectangle
        background = Turtle('square')
        background.shapesize(self.SQUARESIZE * 3/20)
        background.color('black')
        background.stamp()
        background.hideturtle()

        for j in range(3):
            for i in range(3):
                # stamp method used for assigning spaces was found
                # at https://stackoverflow.com/questions/49784195/tic-tac-toe-game-using-turtle
                space = Turtle('square', visible = False)
                space.shapesize(self.SQUARESIZE/20)
                space.color('white')
                space.penup()
                space.goto(i * (self.SQUARESIZE + 2) - (self.SQUARESIZE + 2), j * (self.SQUARESIZE + 2) - (self.SQUARESIZE + 2))
                space.showturtle()
                space.stamp() #each stamp represents space and is its own turtle object

                self.board[j][i] = space #assigns turtle object in list
                space.onclick(lambda x, y, space=space, i=i, j=j: self.spaceClicked(space, i, j, checkResult))

    def spaceClicked(self, space, i, j, checkResult): 
        ''' Marks space when turtle in space is clicked '''
        space.onclick(None) #can't be clicked anymore
        space.hideturtle()
        space.color('black')
        space.sety(space.ycor() - self.FONTSIZE/1.25)
        if self.currentplayer == self.playerone:
            value = 'X'
            self.currentplayer = self.playertwo
        else:
            value = 'O'
            self.currentplayer = self.playerone
        space.write(value, align = 'center', font = self.FONT) #marks space
        self.board[j][i] = value #adds value in list
        checkResult(value)

tictactoe = TicTacToe()