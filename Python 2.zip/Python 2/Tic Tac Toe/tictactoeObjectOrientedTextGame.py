class Space():
    def __init__ (self, value):
        self.value = value

    def markSpace(self, value):
        self.value = value


class Board():
    def __init__ (self):
        self.board = []
        for i in range(9):
            self.board.append(Space('_'))
        self.player_one = ''
        self.player_two = ''
        self.current_player = ''

    def intro(self):
        print('\nWelcome to Tic Tac Toe! Before we start, we need to figure out a few things: ')
        self.player_one = input('Who will be crosses? ').strip()
        self.player_two = input('Who will be naughts? ').strip()
        print('Welcome ' + self.player_one.title() + ' and ' + self.player_two.title() + '!')
        print('The spaces range from 0 to 8, with the 0 being the top-left space and the numbers increasing ' + 
                'as you go left to right. \nThe underscores represent an open space.\n')
        self.printBoard()
        print(self.player_one.title() + ' will start!')
        self.current_player = self.player_one
        self.player_move()

    def printBoard(self):
        for i in range(9):
            if i in range(2, 9, 3):
               print(self.board[i].value, end = None )
               # self.board[i].drawSpace(None)
            else:
                print(self.board[i].value, end = '')
               # self.board[i].drawSpace() 
                print('|', end = '')

    def result(self):
        ''' Checks to see if player won horizontally, vertically, and diagonally '''
        for i in range(0, 7, 3):
            # checks whether any rows are completed
            if self.board[i].value == 'X' or self.board[i].value == 'O':
                if self.board[i].value == self.board[i+1].value == self.board[i+2].value:
                    return self.board[i].value

        for i in range(0, 3):
            # checks whether any columns are completed
            if self.board[i].value == 'X' or self.board[i].value == 'O':
                if self.board[i].value == self.board[i+3].value == self.board[i+6].value:
                    return self.board[i].value

        for i in range(0, 3, 2):
            # checks whether diagonals are completed
            if self.board[i].value == 'X' or self.board[i].value == 'O':
                if i == 0:
                    if self.board[i].value == self.board[4].value == self.board[8].value:
                            return self.board[i].value
                elif i == 2:
                    if self.board[i].value == self.board[4].value == self.board[6].value:
                        return self.board[i].value

        
        spaces = []
        for space in self.board:
            spaces.append(space.value)
        if '_' not in spaces:
            return 'draw'

        return False

    def whoIsWinner(self, winner):
        if winner == 'X':
            print('\n' + self.player_one.title() + ' is the winner!')
        elif winner == 'O':
            print('\n' + self.player_two.title() + ' is the winner!')
        else:
            print('\nNeither player won. It was a draw!') 
        
    def playAgain(self):
        flagFound = False
        while not flagFound:
            playAgain = input('Want to play again? (y for yes and n for no) ')
            if playAgain == 'y' or playAgain == 'n':
                break
        if playAgain == 'n':
            print('Okay, thanks for playing!')
        else:
            self.board = []
            for i in range(9):
                self.board.append(Space('_'))
            self.intro()

    def player_move(self):
        player_move = int(input('Pick a number from 0-8 (9 to quit and 10 to reset): '))
        if player_move == 10:
            self.board = []
            for i in range(9):
                self.board.append(Space('_'))
            self.intro()
        elif player_move < 0 or player_move > 8:
            print('That isn\'t in range! Pick again')
            self.printBoard()
            self.player_move()
        if self.board[player_move].value == '_':
            if self.current_player == self.player_two:
                self.board[player_move].markSpace('O')
                self.current_player = self.player_one
            else:
                self.board[player_move].markSpace('X')
                self.current_player = self.player_two
        else:
            print('That space is already taken! Pick again')
            self.printBoard()
            self.player_move()

        self.printBoard()
        winner = self.result()
        if winner:
            self.whoIsWinner(winner) 
            self.playAgain()
        else:
            self.player_move()

board = Board()
board.intro()