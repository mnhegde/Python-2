from turtle import Turtle, Screen
from tkinter import messagebox

SQUARESIZE = 100
FONTSIZE = 40
FONT = ('Arial', FONTSIZE, 'bold')

class Board():
    def __init__ (self):
        self.board = [['_'] * 3 for i in range(3)]
        self.turn = 'X'
        self.player_one = ''
        self.player_two = ''
        self.current_player = ''

    def intro(self):
        print('\nWelcome to Tic Tac Toe! Before we start, we need to figure out a few things: ')
        self.player_one = input('Who will be crosses? ').strip()
        self.player_two = input('Who will be naughts? ').strip()
        print('Welcome ' + self.player_one.title() + ' and ' + self.player_two.title() + '!')
        print('Click on a space to take it. ' + self.player_one.title() + ' will start!')
        
        self.printBoard()
        self.current_player = self.player_one

    def checkWinner(self, value):
        for j in range(3):
            if self.board[j].count(value) == len(self.board):
                    if value == 'X':
                        self.popupmsg('Winner!', 'The winner is ' + self.player_one + '!')
                    else:
                        self.popupmsg('Winner!', 'The winner is ' + self.player_two + '!')
            for i in range(3):
                if j == 0:
                    if self.board[j][i] == self.board[j+1][i] == self.board[j+2][i]:
                        if value == 'X':
                            self.popupmsg('Winner!', 'The winner is ' + self.player_one + '!')
                        else:
                            self.popupmsg('Winner!', 'The winner is ' + self.player_two + '!')
                    if self.board[j][0] == self.board[j+1][1] == self.board[j+2][2]:
                        if value == 'X':
                            self.popupmsg('Winner!', 'The winner is ' + self.player_one + '!')
                        else:
                            self.popupmsg('Winner!', 'The winner is ' + self.player_two + '!')
                    if self.board[j][2] == self.board[j+1][1] == self.board[j+2][0]:
                        if value == 'X':
                            self.popupmsg('Winner!', 'The winner is ' + self.player_one + '!')
                        else:
                            self.popupmsg('Winner!', 'The winner is ' + self.player_two + '!')
        return False

    def popupmsg(self, alert, msg):
        messagebox.showinfo(alert, msg)
    
    def printBoard(self):
        background = Turtle('square')
        background.shapesize(SQUARESIZE * 3/20)
        background.color('black')
        background.stamp()
        background.hideturtle()

        for j in range(3):
            for i in range(3):
                space = Turtle('square', visible = False)
                space.shapesize(SQUARESIZE/20)
                space.color('white')
                space.penup()
                space.goto(i * (SQUARESIZE + 2) - (SQUARESIZE + 2), j * (SQUARESIZE + 2) - (SQUARESIZE + 2))
                space.showturtle()
                space.stamp()
                
                self.board[j][i] = space
                space.onclick(lambda x, y, space=space, i=i, j=j: self.spaceClicked(space, i, j))

    def spaceClicked(self, space, i, j):
        space.onclick(None)
        space.hideturtle()
        space.color('black')
        space.sety(space.ycor() - FONTSIZE/1.25)
        if self.current_player == self.player_two:
            space.write('O', align = 'center', font = FONT)
            self.current_player = self.player_one
            self.board[j][i] = 'O'
        else:
            space.write('X', align = 'center', font = FONT)
            self.current_player = self.player_two
            self.board[j][i] = 'X'

        self.checkWinner(self.board[j][i])

board = Board()
board.intro()
s = Screen()
s.mainloop()