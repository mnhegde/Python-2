import turtle
from random import choice, randint


screen = turtle.Screen()
image = r"C:\Users\manuh\Downloads\chungus.gif"

screen.addshape(image)

class BigChungus():
    def __init__(self, x, y, vx, vy):
        self.turtle = turtle.Turtle()
        self.turtle.shape(image)
        self.turtle.penup()
        self.t = turtle.Turtle()
        self.t.penup()
        self.t.hideturtle()
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.colors=['red', 'blue', 'green', 'purple', 'brown', 'black']

    def writeWord(self):
        self.t.clear()
        self.t.penup()
        self.t.goto(self.x, self.y)
        self.t.pendown()
        self.t.color(choice(self.colors))
        self.t.write('Ouch!!', font=('Arial', 30, 'bold'))

    def checkPos(self):
        if -500 > self.x or self.x > 500:
            self.writeWord()
            self.vx = self.vx*-1

        if -300 > self.y or self.y > 300:
            self.writeWord()
            self.vy = self.vy*-1

    def move(self):
        while True:
            self.x += self.vx
            self.y += self.vy
            self.turtle.goto(self.x, self.y)
            
            self.checkPos()


chungus = BigChungus(0, 0, randint(-1, 1)+.1, randint(-1, 1)+.1)
screen.ontimer(chungus.move, 10)


screen.listen()
screen.mainloop()






